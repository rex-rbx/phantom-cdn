local vu1 = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local v2 = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/SaveManager.lua"))()
local v3 = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/InterfaceManager.lua"))()
local vu4 = game:GetService("VirtualInputManager")
local v5 = vu1:CreateWindow({
    Title = "Blue Lock Rivals",
    SubTitle = "Soluna",
    TabWidth = 160,
    Size = UDim2.fromOffset(600, 500),
    Acrylic = true,
    Theme = "Darker",
    MinimizeKey = Enum.KeyCode.RightShift
})
local v6 = v5:AddTab({
    Title = "Auto Farm",
    Icon = "swords"
})
local v7 = v5:AddTab({
    Title = "Stats",
    Icon = "bar-chart"
})
local v8 = v5:AddTab({
    Title = "Game Stats",
    Icon = "bar-chart-2"
})
local v9 = v5:AddTab({
    Title = "ESP",
    Icon = "eye"
})
local v10 = v5:AddTab({
    Title = "Styles",
    Icon = "brush"
})
local v11 = v5:AddTab({
    Title = "Flow",
    Icon = "waves"
})
local v12 = v5:AddTab({
    Title = "Misc",
    Icon = "settings"
})
local v13 = v5:AddTab({
    Title = "Settings",
    Icon = "settings"
})
local vu14 = game:GetService("Players")
local vu15 = game:GetService("RunService")
local vu16 = game:GetService("UserInputService")
local vu17 = game:GetService("ReplicatedStorage")
local vu18 = game:GetService("TweenService")
local vu19 = vu14.LocalPlayer
local function vu24(p20)
    local v21 = p20.Character
    if not (v21 and v21.Parent) then
        v21 = p20.CharacterAdded:Wait()
    end
    local v22 = v21:WaitForChild("HumanoidRootPart", 5)
    local v23 = v21:WaitForChild("Humanoid", 5)
    if v22 and v23 then
        return v21, v23, v22
    else
        return nil, nil, nil
    end
end
local vu25, vu26, vu27 = vu24(vu19)
if not vu25 then
    vu27 = nil
    vu25 = nil
    vu26 = nil
end
local vu28 = false
local vu29 = 100
local vu30 = 1000
local vu31 = 0.4
local vu32 = workspace.Gravity
vu19.CharacterAdded:Connect(function(_)
    local v36, v37, v38, v39 = pcall(function()
        local v33, v34, v35 = vu24(vu19)
        return v33, v34, v35
    end)
    if v36 then
        vu25 = v37
        vu26 = v38
        vu27 = v39
    end
end)
local function vu42(p40, p41)
    return p40 + p40 * (math.random(- p41, p41) / 100)
end
local function vu47()
    while vu28 and (vu27 and (vu27.Parent and (vu25 and vu25.Parent))) do
        local v43 = Vector3.new()
        local v44 = workspace.CurrentCamera
        if v44 then
            local v45 = v44.CFrame
            local v46 = v43 + (vu16:IsKeyDown(Enum.KeyCode.W) and v45.LookVector or Vector3.new()) - (vu16:IsKeyDown(Enum.KeyCode.S) and v45.LookVector or Vector3.new()) - (vu16:IsKeyDown(Enum.KeyCode.A) and v45.RightVector or Vector3.new()) + (vu16:IsKeyDown(Enum.KeyCode.D) and v45.RightVector or Vector3.new()) + (vu16:IsKeyDown(Enum.KeyCode.Space) and Vector3.new(0, 1, 0) or Vector3.new()) - (vu16:IsKeyDown(Enum.KeyCode.LeftShift) and Vector3.new(0, 1, 0) or Vector3.new())
            if v46.Magnitude <= 0 then
                vu27.Velocity = Vector3.new(0, 0, 0)
            else
                vu29 = math.min(vu29 + vu31, vu30)
                vu27.Velocity = v46.Unit * math.min(vu42(vu29, 10), vu30) * 0.5
            end
            vu15.RenderStepped:Wait()
        else
            task.wait()
        end
    end
end
vu16.InputBegan:Connect(function(p48, p49)
    if not p49 and p48.KeyCode == Enum.KeyCode.F then
        vu28 = not vu28
        if vu28 then
            workspace.Gravity = 0
            if vu27 and vu27.Parent then
                vu47()
            end
        else
            vu29 = 100
            if vu27 and vu27.Parent then
                vu27.Velocity = Vector3.new(0, 0, 0)
            end
            workspace.Gravity = vu32
        end
    end
end)
local vu50 = vu19
local vu51 = false
local vu52 = false
local vu53 = nil
local vu54 = nil
local vu55 = nil
local function vu61()
    while vu53 do
        local v56 = vu25
        local v57
        if v56 then
            v57 = v56:FindFirstChild("HumanoidRootPart")
        else
            v57 = v56
        end
        if v56 then
            v56 = v56:FindFirstChild("Football")
        end
        if v56 and v57 then
            local v58 = workspace:FindFirstChild("Goals")
            local v59 = v58 and vu19.Team
            local v60 = v59 and (v59.Name == "Away" and v58.Away or v58.Home)
            if v60 then
                v57.CFrame = v60.CFrame
                vu17.Packages.Knit.Services.BallService.RE.Shoot:FireServer(60, nil, nil, Vector3.new(- 0.6976264715194702, - 0.3905344605445862, - 0.6006664633750916))
            end
        end
        task.wait()
    end
end
local function vu96()
    if vu51 or vu52 then
        local vu62 = vu25
        if vu62 and vu62.Parent then
            local vu63 = vu62:FindFirstChild("HumanoidRootPart")
            if vu63 then
                local vu64 = vu17.GameValues
                local vu65 = vu17.Packages.Knit.Services.BallService.RE.Slide
                local v66 = vu17.Packages.Knit.Services.BallService.RE.Shoot
                local v67 = workspace:FindFirstChild("Goals")
                if v67 then
                    local v68 = v67.Away
                    local v69 = v67.Home
                    local vu70 = vu17.Packages.Knit.Services.TeamService.RE.Select
                    if v68 and (v69 and (vu65 and (v66 and (vu70 and vu64)))) then
                        local function vu71()
                            return vu64.State.Value == "Playing"
                        end
                        local function vu72()
                            return vu64.Scored.Value
                        end
                        local function vu74()
                            local v73 = vu19.Team
                            if v73 then
                                v73 = vu19.Team.Name == "Visitor"
                            end
                            return v73
                        end
                        local function v85()
                            if not vu71() or vu72() then
                                return
                            end
                            local v75 = workspace:FindFirstChild("Football")
                            if vu63 and (v75 and (not v75.Anchored and (not v75:FindFirstChild("Char") or v75.Char.Value ~= vu62))) then
                                if vu51 then
                                    vu63:PivotTo(CFrame.new(v75.Position.X, 9, v75.Position.Z))
                                else
                                    local v76 = vu18:Create(vu63, TweenInfo.new(0.3), {
                                        CFrame = CFrame.new(v75.Position.X, 9, v75.Position.Z)
                                    })
                                    v76:Play()
                                    v76.Completed:Wait()
                                end
                            end
                            local v77 = vu14
                            local v78, v79, v80 = ipairs(v77:GetPlayers())
                            while true do
                                local v81
                                v80, v81 = v78(v79, v80)
                                if v80 == nil then
                                    break
                                end
                                if v81 ~= vu19 and v81.Team ~= vu19.Team then
                                    local v82 = v81.Character
                                    local v83
                                    if v82 then
                                        v83 = v82:FindFirstChild("Football")
                                    else
                                        v83 = v82
                                    end
                                    if v82 then
                                        v82 = v82:FindFirstChild("HumanoidRootPart")
                                    end
                                    if v83 and (v82 and vu63) then
                                        if vu51 then
                                            vu63:PivotTo(v83.CFrame * CFrame.new(0, 3, 0))
                                        else
                                            local v84 = vu18:Create(vu63, TweenInfo.new(0.3), {
                                                CFrame = v83.CFrame * CFrame.new(0, 3, 0)
                                            })
                                            v84:Play()
                                            v84.Completed:Wait()
                                        end
                                        vu65:FireServer()
                                        break
                                    end
                                end
                            end
                        end
                        (function()
                            if vu74() then
                                if not (vu62 and vu62:IsDescendantOf(workspace)) then
                                    task.wait(0.5)
                                    if not (vu62 and vu62:IsDescendantOf(workspace)) then
                                        return
                                    end
                                end
                                local v86 = vu17:FindFirstChild("Teams")
                                if v86 then
                                    local v87, v88, v89 = ipairs(v86:GetDescendants())
                                    while true do
                                        local v90
                                        v89, v90 = v87(v88, v89)
                                        if v89 == nil then
                                            break
                                        end
                                        if v90:IsA("ObjectValue") and v90.Value == nil then
                                            local v91 = {
                                                string.sub(v90.Parent.Name, 1, # v90.Parent.Name - 4),
                                                v90.Name
                                            }
                                            vu70:FireServer(unpack(v91))
                                        end
                                    end
                                end
                            else
                                return
                            end
                        end)()
                        if vu74() and not vu71() then
                            return
                        else
                            v85()
                            local v92
                            if vu62 then
                                v92 = vu62:FindFirstChild("Football")
                            else
                                v92 = vu62
                            end
                            if v92 then
                                v66:FireServer(60, nil, nil, Vector3.new(- 0.6976264715194702, - 0.3905344605445862, - 0.6006664633750916))
                            end
                            local v93 = workspace:FindFirstChild("Football")
                            if v93 then
                                if v93:FindFirstChild("Char") and v93.Char.Value ~= vu62 then
                                    return
                                else
                                    if v93:FindFirstChild("BodyVelocity") then
                                        v93.BodyVelocity:Destroy()
                                    end
                                    local v94 = vu19.Team
                                    if v94 then
                                        if v94.Name == "Away" and v68 then
                                            v69 = v68
                                        end
                                        if v69 then
                                            if vu63 then
                                                vu63:PivotTo(v69.CFrame)
                                            end
                                            local vu95 = Instance.new("BodyVelocity")
                                            vu95.Velocity = Vector3.new(0, 0, 0)
                                            vu95.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
                                            vu95.Parent = v93
                                            v93.CFrame = v69.CFrame
                                            task.delay(0.1, function()
                                                if vu95 and vu95.Parent then
                                                    vu95:Destroy()
                                                end
                                            end)
                                        end
                                    else
                                        return
                                    end
                                end
                            else
                                return
                            end
                        end
                    else
                        return
                    end
                else
                    return
                end
            else
                return
            end
        else
            return
        end
    else
        return
    end
end
local function vu111()
    local v97 = vu25
    local v98 = vu27
    if not (v97 and (v98 and (v97.Parent and v98.Parent))) then
        return
    end
    local vu99 = vu17.GameValues
    if not vu99 then
        return
    end
    local v100 = vu17.Packages.Knit.Services.BallService.RE.Slide
    if not (function()
        return vu99.State.Value == "Playing"
    end)() or (function()
        return vu99.Scored.Value
    end)() then
        return
    end
    local v101 = workspace:FindFirstChild("Football")
    if v98 and (v101 and (not v101.Anchored and (not v101:FindFirstChild("Char") or v101.Char.Value ~= v97))) then
        if vu51 then
            v98:PivotTo(CFrame.new(v101.Position.X, 9, v101.Position.Z))
        else
            local v102 = vu18:Create(v98, TweenInfo.new(0.3), {
                CFrame = CFrame.new(v101.Position.X, 9, v101.Position.Z)
            })
            v102:Play()
            v102.Completed:Wait()
        end
    end
    local v103 = vu14
    local v104, v105, v106 = ipairs(v103:GetPlayers())
    while true do
        local v107
        v106, v107 = v104(v105, v106)
        if v106 == nil then
            break
        end
        if v107 ~= vu19 and v107.Team ~= vu19.Team then
            local v108 = v107.Character
            local v109
            if v108 then
                v109 = v108:FindFirstChild("Football")
            else
                v109 = v108
            end
            if v108 then
                v108 = v108:FindFirstChild("HumanoidRootPart")
            end
            if v109 and (v108 and v98) then
                if vu51 then
                    v98:PivotTo(v109.CFrame * CFrame.new(0, 3, 0))
                else
                    local v110 = vu18:Create(v98, TweenInfo.new(0.3), {
                        CFrame = v109.CFrame * CFrame.new(0, 3, 0)
                    })
                    v110:Play()
                    v110.Completed:Wait()
                end
                v100:FireServer()
                break
            end
        end
    end
end
local vu112 = nil
local vu113 = nil
local vu114 = nil
local vu115 = nil
local function vu120(p116, p117, p118)
    local v119 = Instance.new("BoxHandleAdornment")
    v119.Name = "ESP"
    v119.Size = p117
    v119.Color3 = p118
    v119.AlwaysOnTop = true
    v119.ZIndex = 5
    v119.Transparency = 0
    v119.Adornee = p116
    v119.Parent = p116
    return v119
end
local function vu126(p121)
    local v122 = Instance.new("Beam")
    local v123 = Instance.new("Attachment")
    local v124 = Instance.new("Attachment")
    v122.AlwaysOnTop = true
    v122.Name = "Tracer"
    v122.FaceCamera = true
    v122.Width0 = 0.2
    v122.Width1 = 0.2
    v122.Color = ColorSequence.new(Color3.fromRGB(255, 165, 0))
    v123.Parent = p121
    local v125 = vu25
    if v125 then
        v125 = vu25:FindFirstChild("HumanoidRootPart")
    end
    if not (v125 and v125.Parent) then
        v123:Destroy()
        v122:Destroy()
        return nil
    end
    v124.Parent = v125
    v122.Attachment0 = v123
    v122.Attachment1 = v124
    v122.Parent = p121
    return v122
end
local function vu133()
    while vu112 do
        local v127 = vu14
        local v128, v129, v130 = pairs(v127:GetPlayers())
        while true do
            local v131
            v130, v131 = v128(v129, v130)
            if v130 == nil then
                break
            end
            if v131 ~= vu19 and (v131.Character and v131.Character.Parent) then
                local v132 = v131.Character:FindFirstChild("HumanoidRootPart")
                if v132 and not v132:FindFirstChild("ESP") then
                    vu120(v132, Vector3.new(2, 5, 2), Color3.fromRGB(255, 0, 0))
                end
            end
        end
        task.wait()
    end
end
local function vu141()
    while vu113 do
        local v134 = vu14
        local v135, v136, v137 = pairs(v134:GetPlayers())
        while true do
            local v138
            v137, v138 = v135(v136, v137)
            if v137 == nil then
                break
            end
            if v138 ~= vu19 and (v138.Character and (v138.Character.Parent and v138.Team)) then
                local v139 = v138.Character:FindFirstChild("HumanoidRootPart")
                if v139 and not v139:FindFirstChild("ESP") then
                    local v140 = v138.Team.Name == "Home" and Color3.fromRGB(0, 0, 255) or Color3.fromRGB(255, 0, 0)
                    vu120(v139, Vector3.new(2, 5, 2), v140)
                end
            end
        end
        task.wait()
    end
end
local function vu146()
    while vu114 or vu115 do
        local v142 = workspace:FindFirstChild("Football")
        if v142 then
            if vu114 then
                if not v142:FindFirstChild("ESP") then
                    vu120(v142, Vector3.new(2, 2, 2), Color3.fromRGB(255, 165, 0))
                end
            else
                local v143 = v142:FindFirstChild("ESP")
                if v143 then
                    v143:Destroy()
                end
            end
            if vu115 then
                if not v142:FindFirstChild("Tracer") then
                    vu126(v142)
                end
            else
                local v144 = v142:FindFirstChild("Tracer")
                if v144 then
                    v144:Destroy()
                    local v145 = v142:FindFirstChild("Attachment")
                    if v145 then
                        v145:Destroy()
                    end
                end
            end
        end
        task.wait()
    end
end
local function vu152()
    local v147 = workspace:FindFirstChild("Football")
    if v147 then
        local v148, v149, v150 = ipairs(v147:GetChildren())
        while true do
            local v151
            v150, v151 = v148(v149, v150)
            if v150 == nil then
                break
            end
            if v151.Name == "ESP" or (v151.Name == "Tracer" or v151:IsA("Attachment")) then
                v151:Destroy()
            end
        end
    end
end
local function vu160()
    local v153 = vu14
    local v154, v155, v156 = pairs(v153:GetPlayers())
    while true do
        local v157
        v156, v157 = v154(v155, v156)
        if v156 == nil then
            break
        end
        if v157.Character and v157.Character.Parent then
            local v158 = v157.Character:FindFirstChild("HumanoidRootPart")
            if v158 then
                local v159 = v158:FindFirstChild("ESP")
                if v159 then
                    v159:Destroy()
                end
            end
        end
    end
end
local function vu168()
    local v161 = vu14
    local v162, v163, v164 = pairs(v161:GetPlayers())
    while true do
        local v165
        v164, v165 = v162(v163, v164)
        if v164 == nil then
            break
        end
        if v165.Character and v165.Character.Parent then
            local v166 = v165.Character:FindFirstChild("HumanoidRootPart")
            if v166 then
                local v167 = v166:FindFirstChild("ESP")
                if v167 then
                    v167:Destroy()
                end
            end
        end
    end
end
local vu169 = nil
local vu170 = nil
local vu171 = nil
local function vu172()
    while vu171 do
        vu4:SendKeyEvent(true, Enum.KeyCode.Space, false, game)
        task.wait(0.1)
        vu4:SendKeyEvent(false, Enum.KeyCode.Space, false, game)
        task.wait(120)
    end
end
v6:AddToggle("AutoFarmTeleportToggle", {
    Title = "Auto Farm (Teleport)",
    Description = nil,
    Default = false,
    Callback = function(p173)
        vu51 = p173
        if p173 then
            vu52 = false
        end
    end
})
local vu174 = false
v6:AddToggle("AutoStealToggle", {
    Title = "Auto Steal",
    Description = "Enable auto steal",
    Default = false,
    Callback = function(p175)
        vu174 = p175
        if p175 then
            if vu55 and coroutine.status(vu55) ~= "dead" then
                task.cancel(vu55)
            end
            vu55 = task.spawn(vu111)
        else
            if vu55 and coroutine.status(vu55) ~= "dead" then
                task.cancel(vu55)
            end
            vu55 = nil
        end
    end
})
v6:AddToggle("AutoGoalToggle", {
    Title = "Auto Goal",
    Description = "Automatically score goals when you have the ball",
    Default = false,
    Callback = function(p176)
        vu53 = p176
        if p176 then
            if vu54 and coroutine.status(vu54) ~= "dead" then
                task.cancel(vu54)
            end
            vu54 = task.spawn(vu61)
        elseif vu54 then
            task.cancel(vu54)
            vu54 = nil
        end
    end
})
v6:AddToggle("AutoTPBallToggle", {
    Title = "Auto TP Ball",
    Description = "Automatically teleport to the ball",
    Default = false,
    Callback = function(p177)
        autoTPBallEnabled = p177
        if p177 then
            task.spawn(function()
                while autoTPBallEnabled do
                    local v178 = workspace:FindFirstChild("Football")
                    local v179 = vu25
                    if v179 then
                        v179 = vu25:FindFirstChild("HumanoidRootPart")
                    end
                    if v178 and (v179 and v179.Parent) then
                        v179.CFrame = v178.CFrame
                    end
                    task.wait()
                end
            end)
        end
    end
})
v6:AddToggle("AutoGoalKeeperToggle", {
    Title = "Auto Goal Keeper (Rarely Blocks Other Styles With Skills)",
    Description = "Automatically teleport to balls within 120 studs with prediction",
    Default = false,
    Callback = function(p180)
        autoBallRadiusEnabled = p180
        local v181 = vu19
        local vu182 = v181.Character or v181.CharacterAdded:Wait()
        local vu183 = vu182:WaitForChild("HumanoidRootPart", 5)
        if vu183 then
            local vu184 = workspace:FindFirstChild("AGK_VisualRadius")
            if p180 then
                if vu184 then
                    vu184.Parent = workspace
                else
                    vu184 = Instance.new("Part")
                    vu184.Name = "AGK_VisualRadius"
                    vu184.Shape = Enum.PartType.Ball
                    vu184.Material = Enum.Material.ForceField
                    vu184.Size = Vector3.new(120, 120, 120)
                    vu184.Color = Color3.fromRGB(0, 170, 255)
                    vu184.CastShadow = false
                    vu184.Anchored = true
                    vu184.CanCollide = false
                    vu184.CanTouch = false
                    vu184.CanQuery = false
                    vu184.Transparency = 0.5
                    vu184.Parent = workspace
                end
                task.spawn(function()
                    while autoBallRadiusEnabled do
                        if not (vu183 and vu183.Parent) then
                            if vu184 and vu184.Parent then
                                vu184:Destroy()
                            end
                            break
                        end
                        vu184.Position = vu183.Position
                        task.wait()
                    end
                end)
                task.spawn(function()
                    while autoBallRadiusEnabled do
                        local v185 = workspace:FindFirstChild("Football")
                        if v185 and (vu183 and (vu183.Parent and (not v185.Anchored and (not v185:FindFirstChild("Char") or v185.Char.Value ~= vu182)))) then
                            if (v185.Position - vu183.Position).Magnitude <= 120 then
                                local v186 = v185.Velocity.Unit
                                if v185.Velocity.Magnitude < 0.1 then
                                    v186 = (v185.Position - vu183.Position).Unit
                                end
                                local v187 = v185.Position + v186 * 2
                                local v188 = CFrame.new(v187, v185.Position)
                                vu183.CFrame = v188 + v188.LookVector * 2
                            end
                        elseif not (vu183 and vu183.Parent) then
                            if vu184 and vu184.Parent then
                                vu184:Destroy()
                            end
                            break
                        end
                        task.wait()
                    end
                end)
            elseif vu184 and vu184.Parent then
                vu184:Destroy()
            end
        end
    end
})
v6:AddSection("Special Abilities")
v6:AddToggle("NoCDToggle", {
    Title = "No CD",
    Description = nil,
    Default = false,
    Callback = function(p189)
        vu170 = p189
        local vu190 = require(game:GetService("ReplicatedStorage").Controllers.AbilityController)
        if p189 then
            if not vu190._OriginalAbilityCooldown then
                vu190._OriginalAbilityCooldown = vu190.AbilityCooldown
            end
            function vu190.AbilityCooldown(p191, p192, ...)
                return vu190._OriginalAbilityCooldown(p191, p192, 0, ...)
            end
        elseif vu190._OriginalAbilityCooldown then
            vu190.AbilityCooldown = vu190._OriginalAbilityCooldown
            vu190._OriginalAbilityCooldown = nil
        end
    end
})
v6:AddToggle("AntiAFKToggle", {
    Title = "Anti-AFK",
    Description = "Prevent being kicked for inactivity",
    Default = false,
    Callback = function(p193)
        vu171 = p193
        if p193 then
            if vu169 and coroutine.status(vu169) ~= "dead" then
                task.cancel(vu169)
            end
            vu169 = task.spawn(vu172)
            vu1:Notify({
                Title = "Anti-AFK Enabled",
                Content = "You will not be kicked for inactivity",
                Duration = 5
            })
        elseif vu169 then
            task.cancel(vu169)
            vu169 = nil
        end
    end
})
v7:AddSection("Stats")
v7:AddParagraph({
    Title = "",
    Content = "Event Currency: " .. (vu19.ProfileStats and (vu19.ProfileStats.EventCurrency.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Experience: " .. (vu19.ProfileStats and (vu19.ProfileStats.Exp.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Flow Spins: " .. (vu19.ProfileStats and (vu19.ProfileStats.FlowSpins.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Lucky Spins: " .. (vu19.ProfileStats and (vu19.ProfileStats.GachaLuckySpins.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Gacha Spins: " .. (vu19.ProfileStats and (vu19.ProfileStats.GachaSpins.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Level: " .. (vu19.ProfileStats and (vu19.ProfileStats.Level.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Money: " .. (vu19.ProfileStats and (vu19.ProfileStats.Money.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Spins: " .. (vu19.ProfileStats and (vu19.ProfileStats.Spins.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Spinwheel Spins: " .. (vu19.ProfileStats and (vu19.ProfileStats.SpinwheelSpins.Value or "N/A") or "N/A")
})
v7:AddSection("Primary Stats")
v7:AddParagraph({
    Title = "",
    Content = "Flow Bar: " .. (vu19.PlayerStats and (vu19.PlayerStats.FlowBar.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Awakening Bar: " .. (vu19.PlayerStats and (vu19.PlayerStats.AwakeningBar.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Flow: " .. (vu19.PlayerStats and (vu19.PlayerStats.Flow.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Flow RNG: " .. (vu19.PlayerStats and (vu19.PlayerStats.FlowRNG.Value or "N/A") or "N/A")
})
local v194 = v7
local v195 = v7.AddParagraph
local v196 = {
    Title = ""
}
local v197 = "Has Shot: "
local v198 = tostring
local v199 = vu19.PlayerStats
if v199 then
    v199 = vu19.PlayerStats.HasShot.Value
end
v196.Content = v197 .. v198(v199)
v195(v194, v196)
local v200 = v7
local v201 = v7.AddParagraph
local v202 = {
    Title = ""
}
local v203 = "In Awakening: "
local v204 = tostring
local v205 = vu19.PlayerStats
if v205 then
    v205 = vu19.PlayerStats.InAwakening.Value
end
v202.Content = v203 .. v204(v205)
v201(v200, v202)
local v206 = v7
local v207 = v7.AddParagraph
local v208 = {
    Title = ""
}
local v209 = "In Flow: "
local v210 = tostring
local v211 = vu19.PlayerStats
if v211 then
    v211 = vu19.PlayerStats.InFlow.Value
end
v208.Content = v209 .. v210(v211)
v207(v206, v208)
v7:AddParagraph({
    Title = "",
    Content = "Last Event Join: " .. (vu19.PlayerStats and (vu19.PlayerStats.LastEventJoin.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Last Join: " .. (vu19.PlayerStats and (vu19.PlayerStats.LastJoin.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Play Timer: " .. (vu19.PlayerStats and (vu19.PlayerStats.PlayTimer.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Stamina: " .. (vu19.PlayerStats and (vu19.PlayerStats.Stamina.Value or "N/A") or "N/A")
})
v7:AddParagraph({
    Title = "",
    Content = "Style: " .. (vu19.PlayerStats and (vu19.PlayerStats.Style.Value or "N/A") or "N/A")
})
v8:AddSection("Game Stats")
v8:AddParagraph({
    Title = "",
    Content = "Assists: " .. (vu19.GameStats and (vu19.GameStats.Assists.Value or "N/A") or "N/A")
})
v8:AddParagraph({
    Title = "",
    Content = "Goals: " .. (vu19.GameStats and (vu19.GameStats.Goals.Value or "N/A") or "N/A")
})
v8:AddParagraph({
    Title = "",
    Content = "Ping: " .. (vu19.GameStats and (vu19.GameStats.Ping.Value or "N/A") or "N/A")
})
v8:AddParagraph({
    Title = "",
    Content = "Points: " .. (vu19.GameStats and (vu19.GameStats.Points.Value or "N/A") or "N/A")
})
v8:AddParagraph({
    Title = "",
    Content = "Saves: " .. (vu19.GameStats and (vu19.GameStats.Saves.Value or "N/A") or "N/A")
})
v8:AddParagraph({
    Title = "",
    Content = "Steals: " .. (vu19.GameStats and (vu19.GameStats.Steals.Value or "N/A") or "N/A")
})
v9:AddSection("ESP Options")
v9:AddToggle("FootballESPToggle", {
    Title = "Football ESP",
    Description = "Show football ESP overlay",
    Default = false,
    Callback = function(p212)
        vu114 = p212
        if p212 then
            task.spawn(vu146)
        else
            vu152()
        end
    end
})
v9:AddToggle("TracerESPToggle", {
    Title = "Tracer ESP",
    Description = "Show line to football",
    Default = false,
    Callback = function(p213)
        vu115 = p213
        if p213 then
            task.spawn(vu146)
        else
            vu152()
        end
    end
})
v9:AddToggle("PlayerESPToggle", {
    Title = "Player ESP",
    Description = "Show player ESP overlay",
    Default = false,
    Callback = function(p214)
        vu112 = p214
        if p214 then
            task.spawn(vu133)
        else
            vu160()
        end
    end
})
v9:AddToggle("TeamESPToggle", {
    Title = "Team ESP",
    Description = "Show team ESP overlay",
    Default = false,
    Callback = function(p215)
        vu113 = p215
        if p215 then
            task.spawn(vu141)
        else
            vu168()
        end
    end
})
v10:AddSection("Style Selection")
v10:AddButton({
    Title = "Nel Isagi",
    Description = "Select NelISAGGII Style :D",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "NEL Isagi"
        end
    end
})
v10:AddButton({
    Title = "Sae",
    Description = "Sae Style Ez",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Sae"
        end
    end
})
v10:AddButton({
    Title = "KAISER",
    Description = "Select KAISER Style :)",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Kaiser"
        end
    end
})
v10:AddButton({
    Title = "Don Lorenzo",
    Description = "Select Don Lorenzo style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Don Lorenzo"
        end
    end
})
v10:AddButton({
    Title = "Kunigami",
    Description = "Select Kunigami style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Kunigami"
        end
    end
})
v10:AddButton({
    Title = "Aiku",
    Description = "Select Aiku style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Aiku"
        end
    end
})
v10:AddButton({
    Title = "Karasu",
    Description = "Select Karasu style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Karasu"
        end
    end
})
v10:AddButton({
    Title = "Otoya",
    Description = "Select Otoya style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Otoya"
        end
    end
})
v10:AddButton({
    Title = "Bachira",
    Description = "Select Bachira style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Bachira"
        end
    end
})
v10:AddButton({
    Title = "Chigiri",
    Description = "Select Chigiri style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Chigiri"
        end
    end
})
v10:AddButton({
    Title = "Isagi",
    Description = "Select Isagi style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Isagi"
        end
    end
})
v10:AddButton({
    Title = "Gagamaru",
    Description = "Select Gagamaru style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Gagamaru"
        end
    end
})
v10:AddButton({
    Title = "King",
    Description = "Select King style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "King"
        end
    end
})
v10:AddButton({
    Title = "Nagi",
    Description = "Select Nagi style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Nagi"
        end
    end
})
v10:AddButton({
    Title = "Rin",
    Description = "Select Rin style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Rin"
        end
    end
})
v10:AddButton({
    Title = "Sae",
    Description = "Select Sae style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Sae"
        end
    end
})
v10:AddButton({
    Title = "Shidou",
    Description = "Select Shidou style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Shidou"
        end
    end
})
v10:AddButton({
    Title = "Reo",
    Description = "Select Reo style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Reo"
        end
    end
})
v10:AddButton({
    Title = "Yukimiya",
    Description = "Select Yukimiya style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Yukimiya"
        end
    end
})
v10:AddButton({
    Title = "Hiori",
    Description = "Select Hiori style",
    Callback = function()
        if vu50 and vu50.PlayerStats then
            vu50.PlayerStats.Style.Value = "Hiori"
        end
    end
})
v11:AddSection("Flow Selection")
v11:AddButton({
    Title = "Dribbler",
    Description = "Select Dribbler flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Dribbler"
        end
    end
})
v11:AddButton({
    Title = "Prodigy",
    Description = "Select Prodigy flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Prodigy"
        end
    end
})
v11:AddButton({
    Title = "Awakened Genius",
    Description = "Select Awakened Genius flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Awakened Genius"
        end
    end
})
v11:AddButton({
    Title = "Snake",
    Description = "Select Snake flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Snake"
        end
    end
})
v11:AddButton({
    Title = "Wildcard",
    Description = "Select Wildcard flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Wildcard"
        end
    end
})
v11:AddButton({
    Title = "Demon Wings",
    Description = "Select Demon Wings flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Demon Wings"
        end
    end
})
v11:AddButton({
    Title = "Trap",
    Description = "Select Trap flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Trap"
        end
    end
})
v11:AddButton({
    Title = "Genius",
    Description = "Select Genius flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Genius"
        end
    end
})
v11:AddButton({
    Title = "Chameleon",
    Description = "Select Chameleon flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Chameleon"
        end
    end
})
v11:AddButton({
    Title = "King\'s Instinct",
    Description = "Select King\'s Instinct flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "King\'s Instinct"
        end
    end
})
v11:AddButton({
    Title = "Gale Burst",
    Description = "Select Gale Burst flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Gale Burst"
        end
    end
})
v11:AddButton({
    Title = "Monster",
    Description = "Select Monster flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Monster"
        end
    end
})
v11:AddButton({
    Title = "Puzzle",
    Description = "Select Puzzle flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Puzzle"
        end
    end
})
v11:AddButton({
    Title = "Lightning",
    Description = "Select Lightning flow",
    Callback = function()
        if vu50 and (vu50:FindFirstChild("PlayerStats") and vu50.PlayerStats:FindFirstChild("Flow")) then
            vu50.PlayerStats.Flow.Value = "Lightning"
        end
    end
})
v12:AddSection("Misc")
v12:AddButton({
    Title = "Teleport to Ball",
    Description = "Teleport to ball",
    Callback = function()
        local v216 = workspace:FindFirstChild("Football")
        if v216 then
            local v217 = vu19.Character
            if v217 and v217:FindFirstChild("HumanoidRootPart") then
                v217.HumanoidRootPart.CFrame = v216.CFrame
            end
        end
    end
})
v12:AddSection("Character Modifications")
local vu218 = false
local vu219 = "1.2"
v12:AddToggle("SpeedToggle", {
    Title = "Speed Toggle",
    Description = "Toggle CFrame speed (Recommended: 1.2)",
    Default = false,
    Callback = function(p220)
        vu218 = p220
        if p220 then
            task.spawn(function()
                while vu218 do
                    local v221 = vu19.Character
                    if v221 and (v221:FindFirstChild("HumanoidRootPart") and v221:FindFirstChildOfClass("Humanoid")) then
                        local v222 = v221.HumanoidRootPart
                        local v223 = v221.Humanoid.MoveDirection
                        if v223.Magnitude > 0 then
                            v222.CFrame = v222.CFrame + v223 * (tonumber(vu219) or 1.2)
                        end
                    end
                    task.wait()
                end
            end)
        end
    end
})
v12:AddSlider("SpeedValueSlider", {
    Title = "Speed Value",
    Description = nil,
    Min = 1,
    Max = 10,
    Rounding = 1,
    Default = 1.2,
    Callback = function(p224)
        vu219 = tostring(p224)
    end
})
local vu225 = false
local vu226 = "50"
v12:AddToggle("JumpPowerToggle", {
    Title = "Jump Power Toggle",
    Description = "Toggle custom jump power value",
    Default = false,
    Callback = function(p227)
        vu225 = p227
        local v228 = vu19.Character
        if v228 and v228:FindFirstChild("Humanoid") then
            local vu229 = v228.Humanoid
            if p227 then
                task.spawn(function()
                    while vu225 and (vu229 and vu229.Parent) do
                        vu229.JumpPower = tonumber(vu226) or 50
                        task.wait()
                    end
                    if not vu225 and vu19.Character and vu19.Character:FindFirstChild("Humanoid") then
                        vu19.Character.Humanoid.JumpPower = 50
                    end
                end)
            elseif vu229 and vu229.Parent then
                vu229.JumpPower = 50
            end
        end
    end
})
v12:AddSlider("JumpPowerValueSlider", {
    Title = "Jump Power Value",
    Description = nil,
    Min = 50,
    Max = 500,
    Rounding = 0,
    Default = 50,
    Callback = function(p230)
        vu226 = tostring(p230)
        local v231 = vu19.Character
        if vu225 and (v231 and v231:FindFirstChild("Humanoid")) then
            v231.Humanoid.JumpPower = p230
        end
    end
})
local vu232 = false
local vu233 = "70"
v12:AddToggle("FOVToggle", {
    Title = "FOV Toggle",
    Description = "Toggle custom camera FOV value",
    Default = false,
    Callback = function(p234)
        vu232 = p234
        if p234 then
            task.spawn(function()
                while vu232 do
                    if workspace.CurrentCamera then
                        workspace.CurrentCamera.FieldOfView = tonumber(vu233) or 70
                    end
                    task.wait()
                end
                if not vu232 and workspace.CurrentCamera then
                    workspace.CurrentCamera.FieldOfView = 70
                end
            end)
        elseif workspace.CurrentCamera then
            workspace.CurrentCamera.FieldOfView = 70
        end
    end
})
v12:AddSlider("FOVValueSlider", {
    Title = "FOV Value",
    Description = nil,
    Min = 70,
    Max = 120,
    Rounding = 0,
    Default = 70,
    Callback = function(p235)
        vu233 = tostring(p235)
        if vu232 and workspace.CurrentCamera then
            workspace.CurrentCamera.FieldOfView = p235
        end
    end
})
local vu236 = false
v12:AddToggle("InfiniteJumpToggle", {
    Title = "Infinite Jump",
    Description = "Toggle infinite jump ability",
    Default = false,
    Callback = function(p237)
        vu236 = p237
    end
})
game:GetService("UserInputService").JumpRequest:Connect(function()
    if vu236 and vu19.Character and vu19.Character:FindFirstChildOfClass("Humanoid") then
        vu19.Character:FindFirstChildOfClass("Humanoid"):ChangeState(Enum.HumanoidStateType.Jumping)
    end
end)
local vu238 = false
v12:AddToggle("FlyToggle", {
    Title = "Fly",
    Description = "Toggle flying ability (Press F to toggle)",
    Default = false,
    Callback = function(p239)
        vu238 = p239
        vu28 = p239
        if p239 then
            workspace.Gravity = 0
            if not (vu25 and (vu25.Parent and (vu27 and vu27.Parent))) then
                local v240, v241, v242, v243 = pcall(vu24, vu19)
                if v240 then
                    vu27 = v243
                    vu26 = v242
                    vu25 = v241
                else
                    vu28 = false
                    vu238 = false
                    if vu1.Options.FlyToggle then
                        vu1.Options.FlyToggle.Value = false
                        workspace.Gravity = vu32
                        return
                    end
                end
            end
            if vu27 and vu27.Parent then
                task.spawn(vu47)
            end
        else
            vu29 = 100
            if vu27 and vu27.Parent then
                vu27.Velocity = Vector3.new(0, 0, 0)
            end
            workspace.Gravity = vu32
        end
    end
})
v12:AddSlider("FlySpeedSlider", {
    Title = "Fly Speed",
    Description = nil,
    Min = 50,
    Max = 1000,
    Rounding = 0,
    Default = 100,
    Callback = function(p244)
        vu29 = p244
    end
})
v2:SetLibrary(vu1)
v3:SetLibrary(vu1)
v2:SetIgnoreIndexes({})
v3:SetFolder("Soluna")
v2:SetFolder("Soluna/Blue-Lock-Rivals")
v3:BuildInterfaceSection(v13)
v2:BuildConfigSection(v13)
v5:SelectTab(1)
vu1:Notify({
    Title = "Soluna",
    Content = "The script has been loaded.",
    Duration = 8
})
v2:LoadAutoloadConfig()
game:GetService("RunService").Heartbeat:Connect(function()
    if (vu51 or vu52) and vu25 and vu25:FindFirstChild("HumanoidRootPart") then
        pcall(vu96)
    end
end)