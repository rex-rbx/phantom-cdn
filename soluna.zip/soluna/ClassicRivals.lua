-- ts file was generated at discord.gg/25ms


local vu1 = game:GetService("UserInputService")
local vu2 = game:GetService("Players")
local vu3 = game:GetService("RunService")
local vu4 = game:GetService("TweenService")
local v5 = game:GetService("CoreGui")
local vu6 = false
local vu7 = vu2.LocalPlayer
local vu8 = game.Workspace.CurrentCamera
local vu9 = Enum.UserInputType.MouseButton2
local vu10 = 0.1
local vu11 = "Hold"
local vu12 = false
local vu13 = false
local vu14 = false
local vu15 = false
local vu16 = false
local v17 = 20
local v18 = 40
local v19 = 300
local v20 = 300
local vu21 = 40
local v22 = 30
local v23 = 350
local vu24 = 1000
local vu25 = 1000
local vu26 = false
local vu27 = 16
local vu28 = nil
local vu29 = {}
local vu30 = nil
local vu31 = 0
local vu32 = {
    Dark = {
        Background = Color3.fromRGB(0, 0, 0),
        Panel = Color3.fromRGB(15, 15, 15),
        Accent = Color3.fromRGB(100, 100, 100),
        Highlight = Color3.fromRGB(150, 150, 150),
        Text = Color3.fromRGB(255, 255, 255),
        Danger = Color3.fromRGB(255, 255, 255)
    },
    Light = {
        Background = Color3.fromRGB(255, 255, 255),
        Panel = Color3.fromRGB(230, 230, 230),
        Accent = Color3.fromRGB(128, 128, 128),
        Highlight = Color3.fromRGB(100, 100, 100),
        Text = Color3.fromRGB(0, 0, 0),
        Danger = Color3.fromRGB(0, 0, 0)
    }
}
local vu33 = "Dark"
local vu34 = 50
local vu35 = 10000
local vu36 = 0.9
local vu37 = {
    [Enum.KeyCode.W] = Vector3.new(0, 0, - 1),
    [Enum.KeyCode.S] = Vector3.new(0, 0, 1),
    [Enum.KeyCode.A] = Vector3.new(- 1, 0, 0),
    [Enum.KeyCode.D] = Vector3.new(1, 0, 0),
    [Enum.KeyCode.Space] = Vector3.new(0, 1, 0),
    [Enum.KeyCode.LeftControl] = Vector3.new(0, - 1, 0)
}
local vu38 = {}
local vu39 = Vector3.new(0, 0, 0)
local function vu43(p40)
    vu34 = p40
    if vu16 then
        local v41 = vu7.Character
        local v42 = v41 and v41:FindFirstChildOfClass("Humanoid")
        if v42 then
            v42.WalkSpeed = p40
        end
    end
end
local function v51(p44)
    local v45 = p44:WaitForChild("Humanoid")
    local v46 = p44:WaitForChild("HumanoidRootPart")
    if vu16 then
        local v47 = Instance.new("BodyVelocity")
        v47.MaxForce = Vector3.new(vu35, vu35, vu35)
        v47.P = 1250
        v47.Velocity = Vector3.zero
        v47.Parent = v46
        local v48 = Instance.new("BodyGyro")
        v48.MaxTorque = Vector3.new(400000, 400000, 400000)
        v48.D = 150
        v48.P = 5000
        v48.CFrame = v46.CFrame
        v48.Parent = v46
        v45.PlatformStand = true
    else
        v45.PlatformStand = false
        local v49 = v46:FindFirstChild("BodyVelocity")
        if v49 then
            v49:Destroy()
        end
        local v50 = v46:FindFirstChild("BodyGyro")
        if v50 then
            v50:Destroy()
        end
    end
end
vu7.CharacterAdded:Connect(v51)
vu1.InputBegan:Connect(function(p52, p53)
    if not p53 then
        if vu37[p52.KeyCode] then
            vu38[p52.KeyCode] = true
        end
    end
end)
vu1.InputEnded:Connect(function(p54, _)
    if vu37[p54.KeyCode] then
        vu38[p54.KeyCode] = nil
    end
end)
vu3.RenderStepped:Connect(function(_)
    local v55 = vu7.Character
    local v56
    if v55 then
        v56 = v55:FindFirstChild("Humanoid")
    else
        v56 = v55
    end
    local v57
    if v55 then
        v57 = v55:FindFirstChild("HumanoidRootPart")
    else
        v57 = v55
    end
    if v55 and (v56 and v56:GetState() ~= Enum.HumanoidStateType.Dead) then
        if vu16 then
            local v58 = workspace.CurrentCamera.CFrame
            local v59 = Vector3.new(0, 0, 0)
            local v60, v61, v62 = pairs(vu37)
            while true do
                local v63
                v62, v63 = v60(v61, v62)
                if v62 == nil then
                    break
                end
                if vu38[v62] then
                    if v63.Y == 0 then
                        local v64 = v58:VectorToWorldSpace(v63)
                        v59 = v59 + Vector3.new(v64.X, 0, v64.Z).Unit
                    else
                        v59 = v59 + v63
                    end
                end
            end
            if v59.Magnitude > 0 then
                v59 = v59.Unit
            end
            vu39 = vu39 * vu36 + v59 * (1 - vu36)
            local v65 = v57:FindFirstChild("BodyVelocity")
            if v65 then
                v65.Velocity = vu39 * vu34
            end
        end
    end
end)
local function v88(p66, p67, p68, pu69, pu70, p71, pu72)
    local v73 = Instance.new("Frame")
    v73.Size = UDim2.new(0, 250, 0, 50)
    v73.Position = p67
    v73.BackgroundTransparency = 1
    v73.Parent = p66
    local v74 = Instance.new("TextLabel")
    v74.Size = UDim2.new(0, 250, 0, 20)
    v74.Position = UDim2.new(0, 0, 0, 0)
    v74.BackgroundTransparency = 1
    v74.Text = p68
    v74.TextColor3 = vu32[vu33].Text
    v74.TextSize = 14
    v74.Font = Enum.Font.Gotham
    v74.TextXAlignment = Enum.TextXAlignment.Left
    v74.Parent = v73
    local vu75 = Instance.new("Frame")
    vu75.Size = UDim2.new(0, 250, 0, 6)
    vu75.Position = UDim2.new(0, 0, 0, 25)
    vu75.BackgroundColor3 = Color3.fromRGB(50, 50, 60)
    vu75.BorderSizePixel = 0
    vu75.Parent = v73
    local vu76 = Instance.new("Frame")
    vu76.Size = UDim2.new(0, 0, 1, 0)
    vu76.Position = UDim2.new(0, 0, 0, 0)
    vu76.BackgroundColor3 = vu32[vu33].Accent
    vu76.BorderSizePixel = 0
    vu76.Parent = vu75
    local vu77 = Instance.new("TextButton")
    vu77.Size = UDim2.new(0, 20, 0, 20)
    vu77.Position = UDim2.new(0, 0, 0.5, - 10)
    vu77.BackgroundColor3 = vu32[vu33].Accent
    vu77.Text = ""
    vu77.AutoButtonColor = false
    vu77.Parent = v73
    local v78 = Instance.new("UICorner")
    v78.CornerRadius = UDim.new(1, 0)
    v78.Parent = vu77
    local function vu81(p79)
        local v80 = (p79 - pu69) / (pu70 - pu69)
        vu76.Size = UDim2.new(v80, 0, 1, 0)
        vu77.Position = UDim2.new(v80, - 10, 0.5, - 10)
        pu72(p79)
    end
    vu77.InputBegan:Connect(function(pu82)
        if pu82.UserInputType == Enum.UserInputType.MouseButton1 then
            local vu87 = vu3.RenderStepped:Connect(function()
                local v83 = vu1:GetMouseLocation().X
                local v84 = vu75.AbsolutePosition.X
                local v85 = vu75.AbsoluteSize.X
                local v86 = math.clamp((v83 - v84) / v85, 0, 1)
                vu81(pu69 + (pu70 - pu69) * v86)
            end)
            pu82.Changed:Connect(function()
                if pu82.UserInputState == Enum.UserInputState.End then
                    vu87:Disconnect()
                end
            end)
        end
    end)
    vu81(p71)
    return v73
end
local function vu91(p89)
    if not (p89 and p89.Character) then
        return true
    end
    local v90 = p89.Character:FindFirstChildOfClass("Humanoid")
    return (not v90 or v90.Health <= 0) and true or false
end
local function vu93(p92)
    if vu6 then
        if vu7 and p92 then
            if vu7.Team and p92.Team then
                return vu7.Team == p92.Team
            else
                return false
            end
        else
            return false
        end
    else
        return false
    end
end
local v94 = Instance.new("ScreenGui")
v94.Name = "EnhancedGameUI"
v94.ResetOnSpawn = false
v94.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
v94.Parent = v5
local vu95 = Instance.new("BlurEffect")
vu95.Size = 0
vu95.Parent = game.Lighting
local function v111(p96, p97, p98, p99)
    local v100 = Instance.new("Frame")
    v100.Size = UDim2.new(0, 200, 0, 30)
    v100.Position = p97
    v100.BackgroundTransparency = 1
    v100.Parent = p96
    local v101 = Instance.new("TextLabel")
    v101.Size = UDim2.new(0, 130, 1, 0)
    v101.Position = UDim2.new(0, 0, 0, 0)
    v101.BackgroundTransparency = 1
    v101.Text = p98
    v101.TextColor3 = vu32[vu33].Text
    v101.TextSize = 14
    v101.Font = Enum.Font.Gotham
    v101.TextXAlignment = Enum.TextXAlignment.Left
    v101.Parent = v100
    local vu102 = Instance.new("Frame")
    vu102.Size = UDim2.new(0, 50, 0, 24)
    vu102.Position = UDim2.new(0, 140, 0, 3)
    vu102.BackgroundColor3 = Color3.fromRGB(50, 50, 60)
    vu102.BackgroundTransparency = 0.3
    vu102.Parent = v100
    local v103 = Instance.new("UICorner")
    v103.CornerRadius = UDim.new(1, 0)
    v103.Parent = vu102
    local vu104 = Instance.new("Frame")
    vu104.Size = UDim2.new(0, 20, 0, 20)
    vu104.Position = UDim2.new(0, p99 and 27 or 2, 0, 2)
    vu104.BackgroundColor3 = p99 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
    vu104.Parent = vu102
    local v105 = Instance.new("UICorner")
    v105.CornerRadius = UDim.new(1, 0)
    v105.Parent = vu104
    local vu106 = p99
    local function vu107()
        vu4:Create(vu104, TweenInfo.new(0.3, Enum.EasingStyle.Quint), {
            Position = UDim2.new(0, vu106 and 27 or 2, 0, 2),
            BackgroundColor3 = vu106 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        }):Play()
        vu4:Create(vu102, TweenInfo.new(0.3, Enum.EasingStyle.Quint), {
            BackgroundColor3 = vu106 and Color3.fromRGB(60, 60, 70) or Color3.fromRGB(50, 50, 60)
        }):Play()
    end
    vu102.InputBegan:Connect(function(p108)
        if p108.UserInputType == Enum.UserInputType.MouseButton1 then
            vu106 = not vu106
            vu107()
        end
    end)
    v101.InputBegan:Connect(function(p109)
        if p109.UserInputType == Enum.UserInputType.MouseButton1 then
            vu106 = not vu106
            vu107()
        end
    end)
    return v100, function()
        return vu106
    end, function(p110)
        vu106 = p110
        vu107()
    end
end
local function v120(p112, p113, p114, p115)
    local v116 = Instance.new("Frame")
    v116.Size = p113
    v116.Position = p114
    v116.BackgroundColor3 = vu32[vu33].Panel
    v116.BackgroundTransparency = 0.4
    v116.BorderSizePixel = 0
    v116.Parent = p112
    local v117 = Instance.new("UICorner")
    v117.CornerRadius = UDim.new(0, p115 or 12)
    v117.Parent = v116
    local v118 = Instance.new("UIStroke")
    v118.Color = vu32[vu33].Text
    v118.Thickness = 1.5
    v118.Transparency = 0.7
    v118.Parent = v116
    local v119 = Instance.new("UIGradient")
    v119.Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(200, 200, 200))
    })
    v119.Transparency = NumberSequence.new({
        NumberSequenceKeypoint.new(0, 0.7),
        NumberSequenceKeypoint.new(1, 0.9)
    })
    v119.Rotation = 45
    v119.Parent = v116
    return v116
end
local function v129(p121, pu122, pu123, p124, p125)
    local vu126 = Instance.new("TextButton")
    vu126.Size = pu122
    vu126.Position = pu123
    vu126.Text = p124
    vu126.BackgroundColor3 = vu32[vu33].Accent
    vu126.BackgroundTransparency = 0.3
    vu126.TextColor3 = vu32[vu33].Text
    vu126.TextSize = 14
    vu126.Font = Enum.Font.GothamSemibold
    vu126.AutoButtonColor = false
    vu126.Parent = p121
    local v127 = Instance.new("UICorner")
    v127.CornerRadius = UDim.new(0, p125 or 8)
    v127.Parent = vu126
    vu126.MouseEnter:Connect(function()
        vu4:Create(vu126, TweenInfo.new(0.3), {
            BackgroundColor3 = Color3.fromRGB(255, 255, 255),
            TextColor3 = Color3.fromRGB(0, 0, 0),
            BackgroundTransparency = 0.1,
            TextSize = 15
        }):Play()
    end)
    vu126.MouseLeave:Connect(function()
        vu4:Create(vu126, TweenInfo.new(0.3), {
            BackgroundColor3 = vu32[vu33].Accent,
            TextColor3 = vu32[vu33].Text,
            BackgroundTransparency = 0.3,
            TextSize = 14
        }):Play()
    end)
    vu126.MouseButton1Down:Connect(function()
        vu4:Create(vu126, TweenInfo.new(0.1), {
            Size = pu122 - UDim2.new(0, 4, 0, 4),
            Position = pu123 + UDim2.new(0, 2, 0, 2)
        }):Play()
    end)
    vu126.MouseButton1Up:Connect(function()
        local v128 = {
            Size = pu122,
            Position = pu123
        }
        vu4:Create(vu126, TweenInfo.new(0.1), v128):Play()
    end)
    return vu126
end
local v130 = v120(v94, UDim2.new(0, 240, 0, v23), UDim2.new(1, - 230, 0.5, - v23 / 2))
local v131 = Instance.new("TextLabel")
v131.Size = UDim2.new(0, 200, 0, 30)
v131.Position = UDim2.new(0.1, 0, 0.05, 0)
v131.Text = "Active Features"
v131.BackgroundTransparency = 1
v131.TextColor3 = vu32[vu33].Text
v131.TextSize = 18
v131.Font = Enum.Font.GothamBold
v131.TextXAlignment = Enum.TextXAlignment.Left
v131.Parent = v130
local function v139(p132, p133, p134, p135)
    local v136 = Instance.new("Frame")
    v136.Size = UDim2.new(0, 180, 0, 40)
    v136.Position = p133
    v136.BackgroundTransparency = 1
    v136.Parent = p132
    local v137 = Instance.new("TextLabel")
    v137.Size = UDim2.new(0, 40, 1, 0)
    v137.Position = UDim2.new(0, 0, 0, 0)
    v137.Text = p134
    v137.BackgroundTransparency = 1
    v137.TextColor3 = Color3.fromRGB(150, 150, 150)
    v137.TextSize = 20
    v137.Font = Enum.Font.GothamBold
    v137.TextYAlignment = Enum.TextYAlignment.Center
    v137.Parent = v136
    local v138 = Instance.new("TextLabel")
    v138.Size = UDim2.new(0, 140, 1, 0)
    v138.Position = UDim2.new(0, 40, 0, 0)
    v138.Text = p135
    v138.BackgroundTransparency = 1
    v138.TextColor3 = Color3.fromRGB(150, 150, 150)
    v138.TextSize = 14
    v138.Font = Enum.Font.Gotham
    v138.TextXAlignment = Enum.TextXAlignment.Left
    v138.TextYAlignment = Enum.TextYAlignment.Center
    v138.Parent = v136
    return v138, v137
end
local vu140, vu141 = v139(v130, UDim2.new(0.1, 0, 0.15, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189\239\184\143", "ESP: Off", v22)
local vu142, vu143 = v139(v130, UDim2.new(0.1, 0, 0.25, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189", "Infinite Jump: Off", v22)
local vu144, vu145 = v139(v130, UDim2.new(0.1, 0, 0.35, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189", "Aimbot: Off", v22)
local vu146, vu147 = v139(v130, UDim2.new(0.1, 0, 0.45, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189", "Auto Shoot: Off", v22)
local vu148, vu149 = v139(v130, UDim2.new(0.1, 0, 0.55, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189", "NoClip: Off", v22)
local vu150, vu151 = v139(v130, UDim2.new(0.1, 0, 0.65, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189", "WalkSpeed: Off", v22)
local vu152, vu153 = v139(v130, UDim2.new(0.1, 0, 0.75, 0), "\239\191\189\239\191\189\239\191\189\239\191\189\239\191\189", "Team Check: Off", v22)
local vu154 = v129(v94, UDim2.new(0, 110, 0, 40), UDim2.new(0.9, - 120, 0.05, 0), "Settings")
spawn(function()
    while true do
        vu4:Create(vu154, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
            BackgroundTransparency = 0.1
        }):Play()
        wait(1.5)
        vu4:Create(vu154, TweenInfo.new(1.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut), {
            BackgroundTransparency = 0.3
        }):Play()
        wait(1.5)
    end
end)
local vu155 = v120(v94, UDim2.new(0, v19, 0, v20), UDim2.new(0.5, - v19 / 2, 0.5, - v20 / 2))
vu155.Visible = false
local v156 = Instance.new("ScrollingFrame")
v156.Size = UDim2.new(1, 0, 1, 0)
v156.Position = UDim2.new(0, 0, 0, 0)
v156.BackgroundTransparency = 1
v156.ScrollBarThickness = 0
v156.CanvasSize = UDim2.new(0, 0, 0, 0)
v156.Parent = vu155
local v157 = Instance.new("TextLabel")
v157.Size = UDim2.new(0, 250, 0, 40)
v157.Position = UDim2.new(0.5, - 125, 0, vu21)
v157.Text = "Rivals Script"
v157.BackgroundTransparency = 1
v157.TextColor3 = vu32[vu33].Text
v157.TextSize = 22
v157.Font = Enum.Font.GothamBold
v157.TextXAlignment = Enum.TextXAlignment.Center
v157.Parent = v156
local vu158 = Instance.new("ScrollingFrame")
vu158.Size = UDim2.new(1, 0, 1, 0)
vu158.Position = UDim2.new(0, 0, 0, 0)
vu158.BackgroundTransparency = 1
vu158.ScrollBarThickness = 0
vu158.CanvasSize = UDim2.new(0, 0, 0, 0)
vu158.Parent = vu155
local v159 = Instance.new("UICorner")
v159.CornerRadius = UDim.new(0, 12)
v159.Parent = vu158
local vu160 = Instance.new("Frame")
vu160.Name = "ScrollBar"
vu160.Size = UDim2.new(0, 8, 1, - 24)
vu160.Position = UDim2.new(1, - 8, 0, 12)
vu160.BackgroundColor3 = vu32[vu33].Accent
vu160.BackgroundTransparency = 0.5
vu160.BorderSizePixel = 0
vu160.Visible = false
vu160.Parent = vu158
local v161 = Instance.new("UICorner")
v161.CornerRadius = UDim.new(1, 0)
v161.Parent = vu160
local vu162 = Instance.new("Frame")
vu162.Name = "ScrollThumb"
vu162.Size = UDim2.new(1, 0, 0, 50)
vu162.BackgroundColor3 = vu32[vu33].Highlight
vu162.BackgroundTransparency = 0.3
vu162.BorderSizePixel = 0
vu162.Parent = vu160
local v163 = Instance.new("UICorner")
v163.CornerRadius = UDim.new(1, 0)
v163.Parent = vu162
local function v170()
    local v164 = vu158.CanvasSize.Y.Offset
    local v165 = vu158.AbsoluteWindowSize.Y
    local v166 = v165 < v164
    vu160.Visible = v166
    if v166 then
        local v167 = math.max(20, v165 / v164 * vu160.AbsoluteSize.Y)
        vu162.Size = UDim2.new(1, 0, 0, v167)
        local v168 = v164 - v165
        local v169 = vu158.CanvasPosition.Y / v168 * (vu160.AbsoluteSize.Y - vu162.AbsoluteSize.Y)
        vu162.Position = UDim2.new(0, 0, 0, v169)
    end
end
local v171 = vu158
vu158.GetPropertyChangedSignal(v171, "CanvasSize"):Connect(v170)
local v172 = vu158
vu158.GetPropertyChangedSignal(v172, "CanvasPosition"):Connect(v170)
local v173 = vu158
vu158.GetPropertyChangedSignal(v173, "CanvasPosition"):Connect(function()
    local v174 = vu158.CanvasSize.Y.Offset - vu158.AbsoluteWindowSize.Y
    local v175 = vu158.CanvasPosition.Y / v174 * (vu160.AbsoluteSize.Y - vu162.AbsoluteSize.Y)
    vu4:Create(vu162, TweenInfo.new(0.2, Enum.EasingStyle.Quad), {
        Position = UDim2.new(0, 0, 0, v175)
    }):Play()
end)
local vu176 = false
local vu177 = nil
local vu178 = nil
vu162.InputBegan:Connect(function(p179)
    if p179.UserInputType == Enum.UserInputType.MouseButton1 then
        vu176 = true
        vu177 = p179.Position.Y
        vu178 = vu158.CanvasPosition.Y
    end
end)
vu1.InputChanged:Connect(function(p180)
    if vu176 and p180.UserInputType == Enum.UserInputType.MouseMovement then
        local v181 = p180.Position.Y - vu177
        local v182 = vu158.CanvasSize.Y.Offset
        local v183 = v182 - vu158.AbsoluteWindowSize.Y
        local v184 = vu178 + v181 / vu160.AbsoluteSize.Y * v182
        vu158.CanvasPosition = Vector2.new(0, math.clamp(v184, 0, v183))
    end
end)
vu1.InputEnded:Connect(function(p185)
    if p185.UserInputType == Enum.UserInputType.MouseButton1 then
        vu176 = false
    end
end)
local v186 = v129(vu158, UDim2.new(0, 40, 0, 40), UDim2.new(0.9, - 45, 0.02, 0), "X")
v186.TextSize = 20
v186.BackgroundColor3 = vu32[vu33].Danger
local v187, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, (vu21 or 0) + (v18 or 0) + (v17 or 0)), "ESP", vu12)
local vu188 = Instance.new("TextLabel")
vu188.Size = UDim2.new(0, 250, 0, 30)
vu188.Position = UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 6 + 20)
vu188.Text = "Aimbot Keybind: Right Click"
vu188.BackgroundTransparency = 1
vu188.TextColor3 = vu32[vu33].Text
vu188.TextSize = 14
vu188.Font = Enum.Font.Gotham
vu188.TextXAlignment = Enum.TextXAlignment.Left
vu188.Parent = vu158
local v189 = v129(vu158, UDim2.new(0, 250, 0, v18), UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 6 + 50), "Change Keybind")
vu154.MouseButton1Click:Connect(function()
    if vu155.Visible then
        vu4:Create(vu95, TweenInfo.new(0.3), {
            Size = 0
        }):Play()
        vu4:Create(vu155, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
            Size = UDim2.new(0, 400, 0, 0),
            Position = UDim2.new(0.5, - 200, 0.5, 0)
        }):Play()
        wait(0.5)
        vu155.Visible = false
    else
        vu155.Size = UDim2.new(0, 400, 0, 800)
        vu155.Position = UDim2.new(0.5, - 200, 0.5, - 400)
        vu155.Visible = true
        vu4:Create(vu95, TweenInfo.new(0.3), {
            Size = 10
        }):Play()
        vu4:Create(vu155, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
            Size = UDim2.new(0, 400, 0, 800),
            Position = UDim2.new(0.5, - 200, 0.5, - 400)
        }):Play()
    end
end)
v186.MouseButton1Click:Connect(function()
    vu4:Create(vu95, TweenInfo.new(0.3), {
        Size = 0
    }):Play()
    vu4:Create(vu155, TweenInfo.new(0.5, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
        Size = UDim2.new(0, 400, 0, 0),
        Position = UDim2.new(0.5, - 200, 0.5, 0)
    }):Play()
    wait(0.5)
    vu155.Visible = false
end)
v189.MouseButton1Click:Connect(function()
    vu188.Text = "Press any key..."
    vu188.TextColor3 = vu32[vu33].Highlight
    local vu190 = nil
    vu190 = vu1.InputBegan:Connect(function(p191)
        if p191.UserInputType == Enum.UserInputType.Keyboard or (p191.UserInputType == Enum.UserInputType.MouseButton1 or p191.UserInputType == Enum.UserInputType.MouseButton2) then
            if p191.UserInputType ~= Enum.UserInputType.Keyboard then
                vu9 = p191.UserInputType
            else
                vu9 = p191.KeyCode
            end
            vu188.Text = "Aimbot Keybind: " .. (p191.UserInputType == Enum.UserInputType.MouseButton1 and "Left Click" or (p191.UserInputType == Enum.UserInputType.MouseButton2 and "Right Click" or tostring(p191.KeyCode):gsub("Enum.KeyCode.", "")))
            vu188.TextColor3 = vu32[vu33].Text
            vu4:Create(vu188, TweenInfo.new(0.3), {
                TextSize = 16
            }):Play()
            wait(0.3)
            vu4:Create(vu188, TweenInfo.new(0.3), {
                TextSize = 14
            }):Play()
            vu190:Disconnect()
        end
    end)
end)
v88(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 8 + 100), "WalkSpeed", 16, 100, 50, function(p192)
    vu43(p192)
end)
local function vu197(p193)
    if vu12 and p193.Character then
        local v194 = vu7.Character
        if v194 then
            v194 = vu7.Character:FindFirstChild("HumanoidRootPart")
        end
        if v194 then
            local v195 = p193.Character:FindFirstChild("HumanoidRootPart")
            if v195 then
                if vu24 >= (v194.Position - v195.Position).Magnitude then
                    if vu29[p193] then
                        vu29[p193]:Destroy()
                    end
                    local v196 = Instance.new("Highlight")
                    v196.Adornee = p193.Character
                    v196.FillColor = Color3.new(0, 0, 0)
                    v196.OutlineColor = Color3.new(1, 1, 1)
                    v196.FillTransparency = 0.5
                    v196.OutlineTransparency = 0.3
                    v196.Parent = p193.Character
                    vu29[p193] = v196
                end
            else
                return
            end
        else
            return
        end
    else
        return
    end
end
local function vu199(p198)
    if vu29[p198] then
        vu29[p198]:Destroy()
        vu29[p198] = nil
    end
end
local function vu205()
    if vu12 then
        local v200 = vu2
        local v201, v202, v203 = pairs(v200:GetPlayers())
        while true do
            local v204
            v203, v204 = v201(v202, v203)
            if v203 == nil then
                break
            end
            if v204 ~= vu7 and v204.Character then
                vu197(v204)
            end
        end
    end
end
local function vu210()
    local v206, v207, v208 = pairs(vu29)
    while true do
        local v209
        v208, v209 = v206(v207, v208)
        if v208 == nil then
            break
        end
        vu199(v208)
    end
end
vu2.PlayerAdded:Connect(function(pu211)
    pu211.CharacterAdded:Connect(function(_)
        if vu12 then
            wait(0.5)
            vu197(pu211)
        end
    end)
end)
vu7.CharacterAdded:Connect(function(_)
    if vu12 then
        wait(0.5)
        vu205()
    end
end)
vu2.PlayerRemoving:Connect(function(p212)
    if vu29[p212] then
        vu199(p212)
    end
end)
vu7.CharacterAdded:Connect(function(p213)
    local v214 = p213:WaitForChild("Humanoid")
    local v215 = p213:WaitForChild("HumanoidRootPart")
    if vu16 then
        local v216 = Instance.new("BodyVelocity")
        v216.MaxForce = Vector3.new(vu35, vu35, vu35)
        v216.P = 1250
        v216.Velocity = Vector3.zero
        v216.Parent = v215
        local v217 = Instance.new("BodyGyro")
        v217.MaxTorque = Vector3.new(400000, 400000, 400000)
        v217.D = 150
        v217.P = 5000
        v217.CFrame = v215.CFrame
        v217.Parent = v215
        v214.PlatformStand = true
    else
        v214.PlatformStand = false
    end
end)
vu2.PlayerRemoving:Connect(function(p218)
    if vu29[p218] then
        vu199(p218)
    end
end)
v187:GetChildren()[2].InputBegan:Connect(function(p219)
    if p219.UserInputType == Enum.UserInputType.MouseButton1 then
        vu12 = not vu12
        vu140.Text = "ESP: " .. (vu12 and "On" or "Off")
        vu140.TextColor3 = vu12 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
        vu141.TextColor3 = vu12 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
        if vu12 then
            vu205()
        else
            vu210()
        end
    end
end)
local function vu225()
    local v220 = vu7.Character
    if v220 then
        local v221, v222, v223 = pairs(v220:GetDescendants())
        while true do
            local v224
            v223, v224 = v221(v222, v223)
            if v223 == nil then
                break
            end
            if v224:IsA("BasePart") then
                v224.CanCollide = false
                v224.Velocity = Vector3.zero
                v224.RotVelocity = Vector3.zero
            end
        end
    end
end
local function vu231()
    local v226 = vu7.Character
    if v226 then
        local v227, v228, v229 = pairs(v226:GetDescendants())
        while true do
            local v230
            v229, v230 = v227(v228, v229)
            if v229 == nil then
                break
            end
            if v230:IsA("BasePart") then
                v230.CanCollide = true
            end
        end
    end
end
local function vu232()
    vu15 = not vu15
    if vu15 then
        vu225()
    else
        vu231()
    end
    vu148.Text = "NoClip: " .. (vu15 and "On" or "Off")
    vu148.TextColor3 = vu15 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
    vu149.TextColor3 = vu15 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
end
vu7.CharacterAdded:Connect(function(_)
    wait(1)
    if vu15 then
        vu225()
    end
end)
local v233, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 9 + 100), "NoClip", vu15)
v233:GetChildren()[2].InputBegan:Connect(function(p234)
    if p234.UserInputType == Enum.UserInputType.MouseButton1 then
        vu232()
    end
end)
vu3.Heartbeat:Connect(function()
    if vu12 then
        local v235 = vu2
        local v236, v237, v238 = pairs(v235:GetPlayers())
        while true do
            local v239
            v238, v239 = v236(v237, v238)
            if v238 == nil then
                break
            end
            if v239 ~= vu7 and v239.Character then
                local v240 = vu7.Character
                if v240 then
                    v240 = vu7.Character:FindFirstChild("HumanoidRootPart")
                end
                local v241 = v239.Character:FindFirstChild("HumanoidRootPart")
                if v240 and v241 then
                    if (v240.Position - v241.Position).Magnitude > vu24 then
                        vu199(v239)
                    elseif not vu29[v239] then
                        vu197(v239)
                    end
                end
            end
        end
    end
end)
local function vu256()
    local v242 = nil
    local v243 = math.huge
    local v244 = vu1:GetMouseLocation()
    local v245 = vu7.Character
    if v245 then
        v245 = vu7.Character:FindFirstChild("HumanoidRootPart")
    end
    if not v245 then
        return nil
    end
    local v246 = vu2
    local v247, v248, v249 = pairs(v246:GetPlayers())
    while true do
        local v250
        v249, v250 = v247(v248, v249)
        if v249 == nil then
            break
        end
        if v250 ~= vu7 and (v250.Character and not (vu6 and vu93(v250))) and not vu91(v250) then
            local v251 = v250.Character:FindFirstChild("Head")
            if v251 then
                local v252 = (v245.Position - v251.Position).Magnitude
                if v252 <= vu25 then
                    local v253, v254 = vu8:WorldToViewportPoint(v251.Position)
                    if v254 then
                        local v255 = (Vector2.new(v253.X, v253.Y) - v244).Magnitude
                        if v255 < v243 then
                            v242 = v251
                            v243 = v255
                        end
                    elseif v252 < v243 then
                        v242 = v251
                        v243 = v252
                    end
                end
            end
        end
    end
    return v242
end
local function vu262(p257, p258)
    if not (p257 and p257.Position) then
        return Vector3.zero
    end
    if not p257:FindFirstChild("LastPosition") then
        local v259 = Instance.new("Vector3Value")
        v259.Name = "LastPosition"
        v259.Value = p257.Position
        v259.Parent = p257
    end
    local v260 = p257.LastPosition.Value
    local v261 = (p257.Position - v260) / p258
    p257.LastPosition.Value = p257.Position
    return v261
end
local function vu266(p263, p264)
    if not p263 then
        return nil
    end
    local v265 = vu262(p263, p264)
    return p263.Position + v265 * p264 * 2
end
local vu267 = tick()
local vu268 = Instance.new("TextLabel")
vu268.Size = UDim2.new(0, 250, 0, 30)
vu268.Position = UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 7 + 70)
vu268.Text = "Aimbot Sensitivity: " .. vu10
vu268.BackgroundTransparency = 1
vu268.TextColor3 = vu32[vu33].Text
vu268.TextSize = 14
vu268.Font = Enum.Font.Gotham
vu268.TextXAlignment = Enum.TextXAlignment.Left
vu268.Parent = vu158
local vu269 = Instance.new("TextBox")
vu269.Size = UDim2.new(0, 250, 0, v18)
vu269.Position = UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 7 + 100)
vu269.Text = tostring(vu10)
vu269.BackgroundColor3 = vu32[vu33].Panel
vu269.BackgroundTransparency = 0.3
vu269.TextColor3 = vu32[vu33].Text
vu269.TextSize = 14
vu269.Font = Enum.Font.Gotham
vu269.PlaceholderText = "Enter sensitivity (0-5)"
vu269.Parent = vu158
local v270 = Instance.new("UICorner")
v270.CornerRadius = UDim.new(0, 8)
v270.Parent = vu269;
(function()
    local v271 = vu158
    local v272, v273, v274 = pairs(v271:GetChildren())
    local v275 = 0
    while true do
        local v276
        v274, v276 = v272(v273, v274)
        if v274 == nil then
            break
        end
        if v276:IsA("GuiObject") then
            v275 = v275 + v276.Size.Y.Offset + v276.Position.Y.Offset
        end
    end
    vu158.CanvasSize = UDim2.new(0, 0, 0, v275 + vu21 * 2)
end)()
local function vu278()
    local v277 = tonumber(vu269.Text)
    if v277 and (1e-9 <= v277 and v277 <= 5) then
        vu10 = v277
        vu268.Text = "Aimbot Sensitivity: " .. string.format("%.9f", vu10)
    else
        vu269.Text = tostring(vu10)
    end
end
vu269.FocusLost:Connect(function(p279)
    if p279 then
        vu278()
    end
end)
local v280 = vu269
vu269.GetPropertyChangedSignal(v280, "Text"):Connect(function()
    local v281 = vu269.Text:gsub("[^%d.]", "")
    local v282, v283, v284 = v281:gmatch("%.")
    local v285 = 0
    while true do
        v284 = v282(v283, v284)
        if v284 == nil then
            break
        end
        v285 = v285 + 1
        if v285 > 1 then
            v281 = v281:sub(1, - 2)
        end
    end
    vu269.Text = v281
end)
local function vu287(p286)
    if p286 and p286.Parent then
        return vu7.Character and p286:IsDescendantOf(vu7.Character) and true or false
    else
        return false
    end
end
local function vu289()
    if AimbotEnabled and vu26 then
        local v288 = vu256()
        if v288 and not vu287(v288) then
            vu28 = v288
        else
            vu28 = nil
        end
    end
end
spawn(function()
    while wait(0.1) do
        vu289()
    end
end)
local vu290 = Instance.new("TextLabel")
vu290.Size = UDim2.new(0, 250, 0, 30)
vu290.Position = UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 5)
vu290.Text = "Aimbot Mode: " .. vu11
vu290.BackgroundTransparency = 1
vu290.TextColor3 = vu32[vu33].Text
vu290.TextSize = 14
vu290.Font = Enum.Font.Gotham
vu290.TextXAlignment = Enum.TextXAlignment.Left
vu290.Parent = vu158
v129(vu158, UDim2.new(0, 250, 0, v18), UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 5 + 30), "Switch Aimbot Mode").MouseButton1Click:Connect(function()
    if vu11 ~= "Hold" then
        vu11 = "Hold"
    else
        vu11 = "Toggle"
    end
    vu290.Text = "Aimbot Mode: " .. vu11
    vu4:Create(vu290, TweenInfo.new(0.3), {
        TextSize = 16
    }):Play()
    wait(0.3)
    vu4:Create(vu290, TweenInfo.new(0.3), {
        TextSize = 14
    }):Play()
end)
vu1.InputBegan:Connect(function(p291, p292)
    if not p292 and (p291.UserInputType == vu9 or p291.KeyCode and (p291.UserInputType == Enum.UserInputType.Keyboard and p291.KeyCode == vu9)) and vu26 then
        if vu11 ~= "Toggle" then
            AimbotEnabled = true
            vu28 = vu256()
            vu1.MouseBehavior = Enum.MouseBehavior.LockCenter
        else
            AimbotEnabled = not AimbotEnabled
            if AimbotEnabled then
                vu28 = vu256()
                vu1.MouseBehavior = Enum.MouseBehavior.LockCenter
            else
                vu28 = nil
                vu1.MouseBehavior = Enum.MouseBehavior.Default
            end
        end
    end
end)
vu1.InputEnded:Connect(function(p293, _)
    if (p293.UserInputType == vu9 or p293.KeyCode and (p293.UserInputType == Enum.UserInputType.Keyboard and p293.KeyCode == vu9)) and vu11 == "Hold" then
        AimbotEnabled = false
        vu28 = nil
        vu1.MouseBehavior = Enum.MouseBehavior.Default
    end
end)
vu3.RenderStepped:Connect(function()
    local v294 = tick()
    local v295 = v294 - vu267
    vu267 = v294
    if AimbotEnabled and vu26 then
        if not vu28 then
            vu28 = vu256()
        end
        if vu28 and (vu28.Parent and not (vu287(vu28) or vu93(vu28.Parent))) then
            if (vu7.Character.HumanoidRootPart.Position - vu28.Position).Magnitude > vu25 then
                vu28 = nil
            else
                local v296 = vu266(vu28, v295)
                if v296 then
                    local v297 = vu8:WorldToViewportPoint(v296)
                    local v298 = Vector2.new(vu8.ViewportSize.X / 2, vu8.ViewportSize.Y / 2)
                    local v299 = (v297.X - v298.X) * vu10
                    local v300 = (v297.Y - v298.Y) * vu10
                    mousemoverel(v299, v300)
                end
            end
        else
            vu28 = nil
        end
    else
        vu28 = nil
        AimbotEnabled = false
    end
end)
local v301, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 11 + 100), "Team Check", vu6)
v301:GetChildren()[2].InputBegan:Connect(function(p302)
    if p302.UserInputType == Enum.UserInputType.MouseButton1 then
        vu6 = not vu6
    end
end)
local v303, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 3), "Aimbot", vu26)
v303:GetChildren()[2].InputBegan:Connect(function(p304)
    if p304.UserInputType == Enum.UserInputType.MouseButton1 then
        vu26 = not vu26
        AimbotEnabled = false
        vu28 = nil
        vu144.Text = "Aimbot: " .. (not vu26 or AimbotEnabled and "On" or "Off")
        vu144.TextColor3 = vu26 and (AimbotEnabled and vu32[vu33].Accent) or Color3.fromRGB(150, 150, 150)
        vu145.TextColor3 = vu26 and (AimbotEnabled and vu32[vu33].Accent) or Color3.fromRGB(150, 150, 150)
    end
end)
local function vu307()
    if vu14 then
        if vu30 then
            vu30:Disconnect()
            vu30 = nil
        end
        vu30 = vu1.JumpRequest:Connect(function()
            local v305 = vu7.Character
            if v305 then
                local v306 = v305:FindFirstChildOfClass("Humanoid")
                if v306 and v306:GetState() ~= Enum.HumanoidStateType.Dead then
                    v306:ChangeState(Enum.HumanoidStateType.Jumping)
                end
            end
        end)
    elseif vu30 then
        vu30:Disconnect()
        vu30 = nil
    end
end
vu7.CharacterAdded:Connect(function()
    if vu14 then
        vu307()
    end
end)
local v308, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 2), "Infinite Jump", vu14)
v308:GetChildren()[2].InputBegan:Connect(function(p309)
    if p309.UserInputType == Enum.UserInputType.MouseButton1 then
        vu14 = not vu14
        vu142.Text = "Infinite Jump: " .. (vu14 and "On" or "Off")
        vu142.TextColor3 = vu14 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
        vu143.TextColor3 = vu14 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
        if vu14 then
            vu307()
        elseif vu30 then
            vu30:Disconnect()
            vu30 = nil
        end
    end
end)
local function v333()
    local v310 = tick()
    if vu13 then
        if UserIsHoldingMouse then
            AutoShootIsControllingMouse = false
            return
        elseif v310 - vu31 >= 0.05 then
            local v311 = vu1:GetMouseLocation()
            local v312 = vu2
            local v313, v314, v315 = pairs(v312:GetPlayers())
            local v316 = 100
            local v317 = nil
            local vu318 = false
            while true do
                local v319
                v315, v319 = v313(v314, v315)
                if v315 == nil then
                    break
                end
                if v319 ~= vu7 and (v319.Character and (vu7.Character and not (vu6 and vu93(v319)))) and not vu91(v319) then
                    local v320 = v319.Character
                    local v321 = v320:FindFirstChild("HumanoidRootPart")
                    local v322 = {
                        v320:FindFirstChild("Head"),
                        v321
                    }
                    local v323, v324, v325 = pairs(v322)
                    while true do
                        local v326
                        v325, v326 = v323(v324, v325)
                        if v325 == nil then
                            break
                        end
                        if v326 and not vu287(v326) then
                            local v327, v328 = vu8:WorldToViewportPoint(v326.Position)
                            if v328 then
                                local v329 = (Vector2.new(v327.X, v327.Y) - v311).Magnitude
                                if v329 < v316 then
                                    v317 = v326
                                    v316 = v329
                                end
                            end
                        end
                    end
                end
            end
            local v330 = AutoShootIsControllingMouse
            if v317 then
                local v331 = Ray.new(vu8.CFrame.Position, (v317.Position - vu8.CFrame.Position).Unit * 1000)
                local v332, _ = workspace:FindPartOnRayWithIgnoreList(v331, {
                    vu7.Character
                })
                if v332 and (v332:IsDescendantOf(v317.Parent) and not vu287(v332)) then
                    vu318 = true
                    vu31 = v310
                    if not vu1:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
                        mouse1press()
                        AutoShootIsControllingMouse = true
                    end
                end
            end
            if not vu318 and (v330 and not AutoShootCooldown) then
                AutoShootCooldown = true
                spawn(function()
                    wait(0.2)
                    if AutoShootIsControllingMouse and not vu318 then
                        mouse1release()
                        AutoShootIsControllingMouse = false
                    end
                    AutoShootCooldown = false
                end)
            end
        end
    else
        if vu1:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) and AutoShootIsControllingMouse then
            mouse1release()
            AutoShootIsControllingMouse = false
        end
        return
    end
end
local vu334 = false
local vu335 = false
vu1.InputBegan:Connect(function(p336, _)
    if p336.UserInputType == Enum.UserInputType.MouseButton1 then
        vu334 = true
        vu335 = false
    end
end)
vu1.InputEnded:Connect(function(p337, _)
    if p337.UserInputType == Enum.UserInputType.MouseButton1 then
        vu334 = false
    end
end)
vu3.Heartbeat:Connect(v333)
local v338, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 4), "Auto Shoot", vu13)
v338:GetChildren()[2].InputBegan:Connect(function(p339)
    if p339.UserInputType == Enum.UserInputType.MouseButton1 then
        vu13 = not vu13
        vu146.Text = "Auto Shoot: " .. (vu13 and "On" or "Off")
        vu146.TextColor3 = vu13 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
        vu147.TextColor3 = vu13 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 150)
    end
end)
vu3.RenderStepped:Connect(v333)
vu7.CharacterAdded:Connect(function(_)
    if vu12 then
        vu205()
    end
end)
game:GetService("Players").PlayerRemoving:Connect(function(p340)
    if vu29[p340] then
        vu199(p340)
    end
end)
local vu341 = 0
local v342, _, _ = v111(vu158, UDim2.new(0.1, 0, 0, vu21 + (v18 + v17) * 10 + 100), "WalkSpeed", vu16)
v342:GetChildren()[2].InputBegan:Connect(function(p343)
    if p343.UserInputType == Enum.UserInputType.MouseButton1 then
        vu16 = not vu16
        vu150.Text = "WalkSpeed: " .. (vu16 and "On" or "Off")
        vu150.TextColor3 = vu16 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu151.TextColor3 = vu16 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        local v344 = vu7.Character
        if v344 then
            local v345 = v344:FindFirstChildOfClass("Humanoid")
            local v346 = v344:FindFirstChild("HumanoidRootPart")
            if vu16 then
                local v347 = Instance.new("BodyVelocity")
                v347.MaxForce = Vector3.new(vu35, vu35, vu35)
                v347.P = 1250
                v347.Velocity = Vector3.zero
                v347.Parent = v346
                local v348 = Instance.new("BodyGyro")
                v348.MaxTorque = Vector3.new(400000, 400000, 400000)
                v348.D = 150
                v348.P = 5000
                v348.CFrame = v346.CFrame
                v348.Parent = v346
                v345.PlatformStand = true
            else
                v345.PlatformStand = false
                local v349 = v346:FindFirstChild("BodyVelocity")
                if v349 then
                    v349:Destroy()
                end
                local v350 = v346:FindFirstChild("BodyGyro")
                if v350 then
                    v350:Destroy()
                end
            end
        end
    end
end)
vu7.CharacterAdded:Connect(function(p351)
    local v352 = p351:WaitForChild("Humanoid")
    local v353 = p351:WaitForChild("HumanoidRootPart")
    local v354 = Instance.new("BodyVelocity")
    v354.MaxForce = Vector3.new(vu35, vu35, vu35)
    v354.P = 1250
    v354.Velocity = Vector3.zero
    v354.Parent = v353
    if vu16 then
        v352.WalkSpeed = vu34
    else
        v352.WalkSpeed = vu27
        v354.Velocity = Vector3.zero
    end
end)
local vu355 = v129(v94, UDim2.new(0, 110, 0, 40), UDim2.new(0.9, - 240, 0.05, 0), "Discord")
local function vu358(p356)
    local v357 = not (setclipboard or toclipboard) and (not set_clipboard and Clipboard)
    if v357 then
        v357 = Clipboard.set
    end
    if v357 then
        v357(p356)
    else
        warn("Clipboard function not found. Unable to copy text.")
    end
end
vu355.MouseButton1Click:Connect(function()
    vu358("https://discord.gg/gdpCUVj6uS")
    vu355.Text = "Copied"
    wait(2)
    vu355.Text = "Discord"
end);
(function()
    local v359 = tick()
    if v359 - vu341 >= 0.2 then
        vu341 = v359
        vu140.Text = "ESP: " .. (vu12 and "On" or "Off")
        vu140.TextColor3 = vu12 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu141.TextColor3 = vu12 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu142.Text = "Infinite Jump: " .. (vu14 and "On" or "Off")
        vu142.TextColor3 = vu14 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu143.TextColor3 = vu14 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu144.Text = "Aimbot: " .. (not vu26 or AimbotEnabled and "On" or "Off")
        vu144.TextColor3 = vu26 and (AimbotEnabled and vu32[vu33].Accent) or Color3.fromRGB(150, 150, 170)
        vu145.TextColor3 = vu26 and (AimbotEnabled and vu32[vu33].Accent) or Color3.fromRGB(150, 150, 170)
        vu146.Text = "Auto Shoot: " .. (vu13 and "On" or "Off")
        vu146.TextColor3 = vu13 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu147.TextColor3 = vu13 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu150.Text = "WalkSpeed: " .. (vu16 and "On" or "Off")
        vu150.TextColor3 = vu16 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu151.TextColor3 = vu16 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu152.Text = "Team Check: " .. (vu6 and "On" or "Off")
        vu152.TextColor3 = vu6 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
        vu153.TextColor3 = vu6 and vu32[vu33].Accent or Color3.fromRGB(150, 150, 170)
    end
end)()