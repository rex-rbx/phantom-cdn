local vu1 = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local v2 = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/SaveManager.lua"))()
local v3 = loadstring(game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/Addons/InterfaceManager.lua"))()
local v4 = vu1:CreateWindow({
    Title = "Soluna",
    SubTitle = "Forsaken",
    TabWidth = 180,
    Size = UDim2.fromOffset(600, 500),
    Acrylic = true,
    Theme = "Darker",
    MinimizeKey = Enum.KeyCode.RightShift
})
local vu5 = vu1.Options
local v6 = {
    Visuals = v4:AddTab({
        Title = "Visuals",
        Icon = "eye"
    }),
    Utilities = v4:AddTab({
        Title = "Utilities",
        Icon = "hammer"
    }),
    Player = v4:AddTab({
        Title = "Player",
        Icon = "user"
    }),
    Settings = v4:AddTab({
        Title = "Settings",
        Icon = "settings"
    })
}
local v7 = game:GetService("Players")
local vu8 = game:GetService("Workspace")
local v9 = game:GetService("RunService")
local vu10 = game:GetService("ReplicatedStorage")
local vu11 = v7.LocalPlayer
local v12 = "return " .. game:HttpGet("https://raw.githubusercontent.com/dawid-scripts/Fluent/master/dependencies/ESP.lua", true)
local v13, v14 = pcall(loadstring(v12))
local vu15
if v13 and v14 then
    vu15 = v14()
else
    warn("Fluent (Forsaken): Failed to load ESP module. Visuals will be limited.")
    vu1:Notify({
        Title = "Fluent Error",
        Content = "Failed to load ESP module!",
        Duration = 7,
        Type = "Error"
    })
    vu15 = {
        Add = function()
        end,
        Remove = function()
        end,
        Toggle = function()
        end,
        Color = function()
        end,
        Clear = function()
        end,
        Update = function()
        end
    }
end
local vu16 = false
local function vu18()
    local v17 = vu8.Players:FindFirstChild("Killers")
    if v17 and # v17:GetChildren() > 0 then
        return v17:GetChildren()[1]
    else
        return nil
    end
end
local function vu25()
    local v19 = {}
    local v20 = vu8.Players:FindFirstChild("Survivors")
    if v20 then
        local v21, v22, v23 = ipairs(v20:GetChildren())
        while true do
            local v24
            v23, v24 = v21(v22, v23)
            if v23 == nil then
                break
            end
            table.insert(v19, v24)
        end
    end
    return v19
end
local function vu31()
    vu15:Clear("players")
    if vu5.ForsakenEspPlayers and vu5.ForsakenEspPlayers.Value then
        local v26 = vu18()
        if v26 and v26:IsA("Model") then
            vu15:Add(v26, {
                Name = v26.Name .. " (Killer)",
                Color = Color3.fromRGB(255, 0, 0),
                ShowBox = true,
                ShowTracer = true,
                ShowName = true,
                PrimaryPart = v26.PrimaryPart,
                IsEnabled = true,
                Type = "players"
            })
        end
        local v27, v28, v29 = ipairs(vu25())
        while true do
            local v30
            v29, v30 = v27(v28, v29)
            if v29 == nil then
                break
            end
            if v30 and (v30:IsA("Model") and v30.Name ~= vu11.Name) then
                vu15:Add(v30, {
                    Name = v30.Name,
                    Color = Color3.fromRGB(0, 255, 0),
                    ShowBox = true,
                    ShowTracer = false,
                    ShowName = true,
                    PrimaryPart = v30.PrimaryPart,
                    IsEnabled = true,
                    Type = "players"
                })
            end
        end
    end
end
local function vu39()
    vu15:Clear("items")
    local v32 = vu5.ForsakenEspItems and vu5.ForsakenEspItems.Value and vu8.Map:FindFirstChild("Ingame")
    if v32 then
        local v33, v34, v35 = ipairs(v32:GetChildren())
        while true do
            local v36
            v35, v36 = v33(v34, v35)
            if v35 == nil then
                break
            end
            if v36:IsA("Model") and (v36.Name ~= "Map" and v36.PrimaryPart) then
                local v37 = Color3.fromRGB(0, 200, 255)
                local v38 = v36.Name
                if vu5.ForsakenPrioritizeMedkit and (vu5.ForsakenPrioritizeMedkit.Value and v36.Name == "Medkit") then
                    vu15:Add(v36, {
                        Name = "!! MEDKIT !!",
                        Color = Color3.fromRGB(255, 255, 255),
                        ShowBox = false,
                        ShowTracer = true,
                        ShowName = true,
                        PrimaryPart = v36.PrimaryPart,
                        IsEnabled = true,
                        Type = "items"
                    })
                else
                    vu15:Add(v36, {
                        Name = v38,
                        Color = v37,
                        ShowBox = true,
                        ShowTracer = false,
                        ShowName = true,
                        PrimaryPart = v36.PrimaryPart,
                        IsEnabled = true,
                        Type = "items"
                    })
                end
            end
        end
    end
end
local vu40 = {}
local function vu55()
    vu15:Clear("generators")
    local v41, v42, v43 = pairs(vu40)
    while true do
        local v44
        v43, v44 = v41(v42, v43)
        if v43 == nil then
            break
        end
        v44:Disconnect()
    end
    vu40 = {}
    if vu5.ForsakenEspGenerators and vu5.ForsakenEspGenerators.Value then
        local v45 = vu8.Map:FindFirstChild("Ingame")
        if v45 then
            v45 = vu8.Map.Ingame:FindFirstChild("Map")
        end
        if v45 then
            local v46, v47, v48 = ipairs(v45:GetChildren())
            while true do
                local v49
                v48, v49 = v46(v47, v48)
                if v48 == nil then
                    break
                end
                if v49.Name == "Generator" and (v49:IsA("Model") and v49.PrimaryPart) then
                    local v50 = v49:FindFirstChild("Progress")
                    local v51 = v50 and (v50.Value or 0) or 0
                    local v52 = Color3.fromRGB(255, 255, 0)
                    local v53 = string.format("Generator (%.0f%%)", v51)
                    local v54
                    if v51 >= 100 then
                        v52 = Color3.fromRGB(0, 128, 0)
                        v53 = "Generator (DONE)"
                        v54 = false
                    else
                        v54 = true
                    end
                    vu15:Add(v49, {
                        Name = v53,
                        Color = v52,
                        ShowBox = true,
                        ShowTracer = v54,
                        ShowName = true,
                        PrimaryPart = v49.PrimaryPart,
                        IsEnabled = true,
                        Type = "generators"
                    })
                    if v50 then
                        vu40[v49] = v50.Changed:Connect(function()
                            vu55()
                        end)
                    end
                end
            end
        end
    end
end
local function vu66()
    if not (vu11.Character and vu11.Character.PrimaryPart) then
        return nil
    end
    local v56 = vu11.Character.PrimaryPart
    local v57 = nil
    local v58 = math.huge
    local v59 = vu8.Map:FindFirstChild("Ingame")
    if v59 then
        v59 = vu8.Map.Ingame:FindFirstChild("Map")
    end
    if v59 then
        local v60, v61, v62 = ipairs(v59:GetChildren())
        while true do
            local v63
            v62, v63 = v60(v61, v62)
            if v62 == nil then
                break
            end
            if v63.Name == "Generator" and (v63:IsA("Model") and v63.PrimaryPart) then
                local v64 = v63:FindFirstChild("Progress")
                if v64 and v64.Value < 100 then
                    local v65 = (v56.Position - v63.PrimaryPart.Position).Magnitude
                    if v65 < v58 then
                        v58 = v65
                        v57 = v63
                    end
                end
            end
        end
    end
    return v57
end
local v67 = v6.Visuals:AddSection("ESP Settings")
v67:AddToggle("ForsakenEspPlayers", {
    Title = "Players ESP",
    Description = "Highlights survivors and the killer.",
    Default = false,
    Callback = vu31
})
v67:AddToggle("ForsakenEspItems", {
    Title = "Items ESP",
    Description = "Highlights items on the map.",
    Default = false,
    Callback = vu39
})
v67:AddToggle("ForsakenPrioritizeMedkit", {
    Title = "Prioritize Medkit",
    Description = "Highlights Medkits with a tracer if Item ESP is on.",
    Default = false,
    Callback = vu39
})
v67:AddToggle("ForsakenEspGenerators", {
    Title = "Generators ESP",
    Description = "Highlights generators and their progress.",
    Default = false,
    Callback = vu55
})
v6.Utilities:AddSection("hammer"):AddButton({
    Title = "Finish Closest Generator Puzzle",
    Description = "Automatically solves the puzzle for the nearest generator.",
    Callback = function()
        if vu16 then
            vu1:Notify({
                Title = "Fluent",
                Content = "Cooldown active, please wait.",
                Duration = 3,
                Type = "Warning"
            })
        else
            local v68 = vu66()
            if v68 and v68:FindFirstChild("Remotes") and v68.Remotes:FindFirstChild("RE") then
                v68.Remotes.RE:FireServer()
                vu1:Notify({
                    Title = "Fluent",
                    Content = "Attempted to solve generator puzzle.",
                    Duration = 3
                })
                vu16 = true
                task.delay(10, function()
                    vu16 = false
                end)
            else
                vu1:Notify({
                    Title = "Fluent",
                    Content = "No unfinished generator found nearby.",
                    Duration = 3,
                    Type = "Error"
                })
            end
        end
    end
})
local v69 = v6.Player:AddSection("Player Modifications")
v69:AddToggle("ForsakenInfiniteStamina", {
    Title = "Infinite Stamina",
    Description = "Prevents stamina from decreasing when sprinting.",
    Default = false,
    Callback = function(p70)
        vu1:Notify({
            Title = "Fluent",
            Content = "Infinite Stamina " .. (p70 and "Enabled" or "Disabled"),
            Duration = 3
        })
    end
})
v69:AddInput("ForsakenSprintSpeed", {
    Title = "Sprinting Speed",
    Description = "Set Your Sprinting Speed",
    Default = "26",
    Placeholder = "e.g., 30",
    Numeric = true,
    Finished = true,
    Callback = function(p71)
        local vu72 = tonumber(p71)
        if vu72 then
            pcall(function()
                require(vu10.Systems.Character.Game.Sprinting).SprintSpeed = vu72
            end)
            vu1:Notify({
                Title = "Fluent",
                Content = "Sprint speed set to " .. vu72,
                Duration = 3
            })
        else
            vu1:Notify({
                Title = "Fluent",
                Content = "Invalid speed value.",
                Duration = 3,
                Type = "Error"
            })
        end
    end
})
v69:AddInput("ForsakenStaminaGain", {
    Title = "Stamina Gain Rate",
    Description = "Set Your Stamina Regenerate Rate",
    Default = "20",
    Placeholder = "e.g., 25",
    Numeric = true,
    Finished = true,
    Callback = function(p73)
        local vu74 = tonumber(p73)
        if vu74 then
            pcall(function()
                require(vu10.Systems.Character.Game.Sprinting).StaminaGain = vu74
            end)
            vu1:Notify({
                Title = "Fluent",
                Content = "Stamina gain rate set to " .. vu74,
                Duration = 3
            })
        else
            vu1:Notify({
                Title = "Fluent",
                Content = "Invalid rate value.",
                Duration = 3,
                Type = "Error"
            })
        end
    end
})
local function vu84()
    local v75 = vu8:FindFirstChild("Players")
    local v76 = vu8.Map
    if v76 then
        v76 = vu8.Map:FindFirstChild("Ingame")
    end
    local v77
    if v76 then
        v77 = v76:FindFirstChild("Map")
    else
        v77 = v76
    end
    if v75 then
        local v78 = v75:FindFirstChild("Survivors")
        local v79 = v75:FindFirstChild("Killers")
        if v78 then
            v78.ChildAdded:Connect(vu31)
            v78.ChildRemoved:Connect(vu31)
        end
        if v79 then
            v79.ChildAdded:Connect(vu31)
            v79.ChildRemoved:Connect(vu31)
        end
    end
    if v76 then
        v76.ChildAdded:Connect(function(p80)
            if p80.Name ~= "Map" then
                vu39()
            end
        end)
        v76.ChildRemoved:Connect(function(p81)
            if p81.Name ~= "Map" then
                vu39()
            end
        end)
    end
    if v77 then
        v77.ChildAdded:Connect(function(p82)
            if p82.Name == "Generator" then
                vu55()
            end
        end)
        v77.ChildRemoved:Connect(function(p83)
            if p83.Name == "Generator" then
                vu55()
            end
        end)
    end
end
task.spawn(function()
    task.wait(2)
    vu31()
    vu39()
    vu55()
    vu84()
end)
v9.RenderStepped:Connect(function()
    if vu15 and vu15.Update then
        vu15:Update()
    end
    if vu5.ForsakenInfiniteStamina and vu5.ForsakenInfiniteStamina.Value then
        pcall(function()
            local v85 = require(vu10.Systems.Character.Game.Sprinting)
            v85.StaminaLossDisabled = true
            v85.StaminaLoss = 0
            if v85.__staminaChangedEvent then
                v85.__staminaChangedEvent:Fire(v85.Stamina)
            end
        end)
    end
end)
v4:SelectTab(1)
vu1:Notify({
    Title = "Fluent (Forsaken Edition)",
    Content = "Script Loaded Successfully!",
    Duration = 5
})
v2:SetLibrary(vu1)
v3:SetLibrary(vu1)
v2:IgnoreThemeSettings()
v2:SetIgnoreIndexes({})
v3:SetFolder("Soluna")
v2:SetFolder("Soluna/Forsaken")
v3:BuildInterfaceSection(v6.Settings)
v2:BuildConfigSection(v6.Settings)
v4:SelectTab(1)
vu1:Notify({
    Title = "Fluent",
    Content = "The script has been loaded.",
    Duration = 8
})
v2:LoadAutoloadConfig()