local vu1 = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local v2 = game:GetService("RunService")
local vu3 = game:GetService("Players")
local vu4 = game:GetService("Workspace")
local vu5 = vu3.LocalPlayer
local vu6 = vu4.CurrentCamera
local v7 = vu5
local vu8 = vu5.GetMouse(v7)
local vu9 = 0
local vu10 = false
local vu11 = 0.005
local vu12 = true
local vu13 = false
local vu14 = 16
local vu15 = 100
local vu16 = false
local vu17 = 0
local vu18 = false
local vu19 = 0.001
local vu20 = 0
local vu21 = 0
local vu22 = true
local vu23 = false
local vu24 = false
local vu25 = Vector3.new(0, 0, 0)
local vu26 = false
local vu27 = Vector3.new(0.1, - 1.7, 0)
local vu28 = false
local vu29 = false
local vu30 = false
local vu31 = nil
local vu32 = "Gib_F"
local vu33 = false
local v34 = vu1
local v35 = vu1.CreateWindow(v34, {
    Name = "Soluna",
    Icon = 10734897102,
    LoadingTitle = "[FPS] Gun Grounds FFA",
    LoadingSubtitle = "By Soluna",
    ConfigurationSaving = {
        Enabled = true,
        FolderName = nil,
        FileName = "SolunaGunGroundsFFA"
    },
    Discord = {
        Enabled = true,
        Invite = "gdpCUVj6uS",
        RememberJoins = true
    },
    KeySystem = false,
    KeySettings = {
        Title = "Soluna Premium",
        Subtitle = "Key System",
        Note = "Key is in Discord: https://discord.gg/gdpCUVj6uS",
        FileName = "Key",
        SaveKey = false,
        GrabKeyFromSite = true,
        Key = {
            "SolunaPremium"
        }
    },
    Theme = {
        TextColor = Color3.fromRGB(230, 230, 230),
        Background = Color3.fromRGB(15, 15, 15),
        Topbar = Color3.fromRGB(20, 20, 20),
        Shadow = Color3.fromRGB(10, 10, 10),
        NotificationBackground = Color3.fromRGB(15, 15, 15),
        NotificationActionsBackground = Color3.fromRGB(40, 40, 40),
        TabBackground = Color3.fromRGB(25, 25, 25),
        TabStroke = Color3.fromRGB(30, 30, 30),
        TabBackgroundSelected = Color3.fromRGB(50, 50, 50),
        TabTextColor = Color3.fromRGB(220, 220, 220),
        SelectedTabTextColor = Color3.fromRGB(255, 255, 255),
        ElementBackground = Color3.fromRGB(20, 20, 20),
        ElementBackgroundHover = Color3.fromRGB(30, 30, 30),
        SecondaryElementBackground = Color3.fromRGB(15, 15, 15),
        ElementStroke = Color3.fromRGB(35, 35, 35),
        SecondaryElementStroke = Color3.fromRGB(30, 30, 30),
        SliderBackground = Color3.fromRGB(80, 80, 80),
        SliderProgress = Color3.fromRGB(120, 120, 120),
        SliderStroke = Color3.fromRGB(150, 150, 150),
        ToggleBackground = Color3.fromRGB(25, 25, 25),
        ToggleEnabled = Color3.fromRGB(200, 200, 200),
        ToggleDisabled = Color3.fromRGB(80, 80, 80),
        ToggleEnabledStroke = Color3.fromRGB(220, 220, 220),
        ToggleDisabledStroke = Color3.fromRGB(100, 100, 100),
        ToggleEnabledOuterStroke = Color3.fromRGB(80, 80, 80),
        ToggleDisabledOuterStroke = Color3.fromRGB(50, 50, 50),
        DropdownSelected = Color3.fromRGB(25, 25, 25),
        DropdownUnselected = Color3.fromRGB(20, 20, 20),
        InputBackground = Color3.fromRGB(20, 20, 20),
        InputStroke = Color3.fromRGB(45, 45, 45),
        PlaceholderColor = Color3.fromRGB(140, 140, 140)
    }
})
local v36 = v35:CreateTab("Aimbot", "target")
local v37 = v35:CreateTab("Gun Mods", "sword")
local v38 = v35:CreateTab("Viewmodel", "eye")
local v39 = v35:CreateTab("Player", "user")
v37:CreateKeybind({
    Name = "Force Reset",
    CurrentKeybind = "T",
    HoldToInteract = false,
    Flag = "ForceReset",
    Callback = function(_)
        if vu5.Character then
            vu5.Character.Humanoid:TakeDamage(vu5.Character.Humanoid.Health)
            vu1:Notify({
                Title = "Force Reset",
                Content = "Done!",
                Duration = 1,
                Image = 4483362458
            })
        end
    end
})
v37:CreateToggle({
    Name = "Gun Mods Enabled",
    CurrentValue = false,
    Flag = "GunModsEnabled",
    Callback = function(p40)
        vu18 = p40
        if p40 then
            vu1:Notify({
                Title = "Gun Mod",
                Content = "Reset to enable!",
                Duration = 1,
                Image = 4483362458
            })
        else
            vu1:Notify({
                Title = "Gun Mod",
                Content = "Reset to disable!",
                Duration = 1,
                Image = 4483362458
            })
        end
        while vu18 do
            if vu5.Character then
                local v41 = vu5.Character:FindFirstChildWhichIsA("Tool")
                if v41 and v41:FindFirstChild("Configuration") then
                    local v42, v43, v44 = ipairs(v41.Configuration:GetChildren())
                    while true do
                        local v45
                        v44, v45 = v42(v43, v44)
                        if v44 == nil then
                            break
                        end
                        if v45.Name == "FireRate" and not vu33 then
                            vu33 = true
                            v45.Value = v45.Value * vu19
                        end
                        if v45.Name == "reloadTime" then
                            v45.Value = vu20
                        end
                        if v45.Name == "DamageDropoff" then
                            v45.Value = vu21
                        end
                        if v45.Name == "isAuto" then
                            v45.Value = vu22
                        end
                        if v45.Name == "DelayedShell" then
                            v45.Value = vu23
                        end
                        if v45.Name == "Recoil" and vu24 then
                            v45.Value = vu25
                        end
                    end
                    if vu28 then
                        local v46 = v41.Configuration:FindFirstChild("HitEffect")
                        if v46 then
                            v46.Value = vu32
                        else
                            local v47 = Instance.new("StringValue")
                            v47.Name = "HitEffect"
                            v47.Value = vu32
                            v47.Parent = v41.Configuration
                        end
                    end
                else
                    vu33 = false
                end
            end
            task.wait()
        end
    end
})
v37:CreateSlider({
    Name = "Fire Rate",
    Range = {
        0,
        1
    },
    Increment = 0.1,
    CurrentValue = 0.3,
    Flag = "FireRate",
    Callback = function(p48)
        vu19 = p48
        vu1:Notify({
            Title = "Fire Rate",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateSlider({
    Name = "Reload Time",
    Range = {
        0,
        100
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "ReloadTime",
    Callback = function(p49)
        vu20 = p49
        vu1:Notify({
            Title = "Reload Time",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateSlider({
    Name = "Damage Drop Off",
    Range = {
        0,
        100
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "DamageDropOff",
    Callback = function(p50)
        vu21 = p50
        vu1:Notify({
            Title = "Damage Drop Off",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateToggle({
    Name = "Force Auto",
    CurrentValue = true,
    Flag = "ForceAuto",
    Callback = function(p51)
        vu22 = p51
        vu1:Notify({
            Title = "Force Auto",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateToggle({
    Name = "Rapid Shotguns",
    CurrentValue = true,
    Flag = "RapidShotguns",
    Callback = function(p52)
        vu23 = not p52
        vu1:Notify({
            Title = "Rapid Shotguns",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateToggle({
    Name = "Recoil Modifier",
    CurrentValue = false,
    Flag = "RecoilModifier",
    Callback = function(p53)
        vu24 = p53
        if p53 then
            vu1:Notify({
                Title = "Recoil Modifier",
                Content = "Reset to enable!",
                Duration = 1,
                Image = 4483362458
            })
        else
            vu1:Notify({
                Title = "Recoil Modifier",
                Content = "Reset to disable!",
                Duration = 1,
                Image = 4483362458
            })
        end
    end
})
v37:CreateSlider({
    Name = "Recoil X",
    Range = {
        0,
        100
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "RecoilX",
    Callback = function(p54)
        vu25 = Vector3.new(p54, vu25.Y, vu25.Z)
        vu1:Notify({
            Title = "Recoil X",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateSlider({
    Name = "Recoil Y",
    Range = {
        0,
        100
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "RecoilY",
    Callback = function(p55)
        vu25 = Vector3.new(vu25.X, p55, vu25.Z)
        vu1:Notify({
            Title = "Recoil Y",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateSlider({
    Name = "Recoil Z",
    Range = {
        0,
        100
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "RecoilZ",
    Callback = function(p56)
        vu25 = Vector3.new(vu25.X, vu25.Y, p56)
        vu1:Notify({
            Title = "Recoil Z",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v37:CreateToggle({
    Name = "Hit Effect [FE]",
    CurrentValue = false,
    Flag = "HitEffectEnabled",
    Callback = function(p57)
        vu28 = p57
        if p57 then
            vu1:Notify({
                Title = "Hit Effect",
                Content = "Reset to enable!",
                Duration = 1,
                Image = 4483362458
            })
        else
            vu1:Notify({
                Title = "Hit Effect",
                Content = "Reset to disable!",
                Duration = 1,
                Image = 4483362458
            })
        end
    end
})
v37:CreateDropdown({
    Name = "Select Hit Effect",
    Options = {
        "Gib_W",
        "Gib_G",
        "Gib_H",
        "Gib_T",
        "Gib_F"
    },
    CurrentOption = "Gib_F",
    Flag = "HitEffect",
    Callback = function(p58)
        if type(p58) ~= "table" then
            vu32 = p58
        else
            vu32 = p58[1]
        end
        vu1:Notify({
            Title = "Hit Effect",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
local vu59 = Drawing.new("Circle")
vu59.Thickness = 2
vu59.NumSides = 12
vu59.Radius = vu15
vu59.Filled = false
vu59.Color = Color3.fromRGB(255, 0, 0)
vu59.Visible = false
local vu60 = nil
local function vu67(p61)
    local v62 = p61:FindFirstChild("Head")
    if not v62 then
        return true
    end
    local v63 = vu6.CFrame.Position
    local v64 = (v62.Position - v63).unit * (v62.Position - v63).magnitude
    local v65 = RaycastParams.new()
    v65.FilterDescendantsInstances = {
        vu5.Character,
        p61
    }
    v65.FilterType = Enum.RaycastFilterType.Blacklist
    local v66 = vu4:Raycast(v63, v64, v65)
    if v66 then
        v66 = v66.Instance ~= nil
    end
    return v66
end
local function vu81()
    local v68 = vu15
    local v69 = math.huge
    local v70 = vu6.CFrame.Position
    local v71 = vu3
    local v72, v73, v74 = ipairs(v71:GetPlayers())
    local v75 = nil
    while true do
        local v76
        v74, v76 = v72(v73, v74)
        if v74 == nil then
            break
        end
        if v76 ~= vu5 and v76.Character and (v76.Character:FindFirstChild("Humanoid") and v76.Character.Humanoid.Health > 0) then
            local v77 = v76.Character:FindFirstChild("Head")
            if v77 then
                local v78 = vu6:WorldToViewportPoint(v77.Position)
                local v79 = (Vector2.new(v78.X, v78.Y) - Vector2.new(vu8.X, vu8.Y)).Magnitude
                local v80 = (v77.Position - v70).Magnitude
                if v79 < v68 and (v78.Z > 0 and not (vu12 and vu67(v76.Character))) then
                    if v80 < v69 then
                        v75 = v76
                        v69 = v80
                        v68 = v79
                    end
                end
            end
        end
    end
    return v75
end
local function vu85(p82)
    if not (p82 and p82.Character and (p82.Character:FindFirstChild("Head") and p82.Character:FindFirstChild("HumanoidRootPart"))) then
        return nil
    end
    local v83 = p82.Character.Head
    local v84 = p82.Character.HumanoidRootPart.Velocity
    return v83.Position + v84 * vu17
end
local function vu87(p86)
    if p86 then
        vu6.CFrame = CFrame.new(vu6.CFrame.Position, p86)
    end
end
v2.RenderStepped:Connect(function()
    if vu29 then
        vu59.Position = Vector2.new(vu8.X, vu8.Y + 50)
        if vu10 then
            vu9 = vu9 + vu11
            if vu9 > 1 then
                vu9 = 0
            end
            vu59.Color = Color3.fromHSV(vu9, 1, 1)
        end
        if vu16 then
            if vu60 and (not vu60.Character or (not vu60.Character:FindFirstChild("Humanoid") or vu60.Character.Humanoid.Health <= 0)) then
                vu60 = nil
                vu31 = nil
            end
            if not vu60 then
                vu60 = vu81()
            end
            if vu60 and vu60.Character then
                local v88 = vu85(vu60)
                if v88 then
                    vu31 = v88
                    vu87(v88)
                elseif vu31 then
                    vu87(vu31)
                end
            else
                vu30 = false
                vu31 = nil
            end
        else
            vu60 = nil
            vu30 = false
            vu31 = nil
        end
    end
end)
vu8.Button2Down:Connect(function()
    if vu29 then
        vu16 = true
    end
end)
vu8.Button2Up:Connect(function()
    if vu29 then
        vu16 = false
    end
end)
v36:CreateToggle({
    Name = "Aimbot",
    CurrentValue = false,
    Flag = "Aimbot",
    Callback = function(p89)
        vu29 = p89
        vu59.Visible = p89
        if not p89 then
            vu60 = nil
            vu30 = false
            vu31 = nil
        end
    end
})
v36:CreateToggle({
    Name = "Wall Check",
    CurrentValue = true,
    Flag = "WallCheck",
    Callback = function(p90)
        vu12 = p90
    end
})
v36:CreateSlider({
    Name = "Aimbot Fov",
    Range = {
        0,
        360
    },
    Increment = 1,
    CurrentValue = 100,
    Flag = "AimbotFov",
    Callback = function(p91)
        vu15 = p91
        vu59.Radius = vu15
    end
})
v36:CreateColorPicker({
    Name = "Fov Color",
    Color = vu59.Color,
    Callback = function(p92)
        vu59.Color = p92
    end
})
v36:CreateToggle({
    Name = "Rainbow Fov",
    CurrentValue = false,
    Flag = "RainbowFov",
    Callback = function(p93)
        vu10 = p93
    end
})
v36:CreateSlider({
    Name = "Rainbow Speed",
    Range = {
        1,
        10
    },
    Increment = 1,
    CurrentValue = 5,
    Flag = "RainbowSpeed",
    Callback = function(p94)
        vu11 = p94 * 0.001
    end
})
local vu95 = false
local vu96 = 5
local vu97 = 0.7
local vu98 = BrickColor.new("Really blue")
v36:CreateToggle({
    Name = "Hitbox Changer",
    CurrentValue = false,
    Flag = "HitboxChanger",
    Callback = function(p99)
        vu95 = p99
        if not vu95 then
            local v100, v101, v102 = ipairs(game:GetService("Players"):GetPlayers())
            while true do
                local v103
                v102, v103 = v100(v101, v102)
                if v102 == nil then
                    break
                end
                if v103 ~= game.Players.LocalPlayer then
                    local v104 = v103.Character
                    if v104 and v104:FindFirstChild("HumanoidRootPart") then
                        local v105 = v104.HumanoidRootPart
                        v105.Size = Vector3.new(2, 2, 1)
                        v105.Transparency = 0
                        v105.BrickColor = BrickColor.new("Medium stone grey")
                        v105.Material = Enum.Material.Plastic
                        v105.CanCollide = true
                    end
                end
            end
        end
    end
})
v36:CreateSlider({
    Name = "Hitbox Size",
    Range = {
        1,
        50
    },
    Increment = 1,
    CurrentValue = vu96,
    Flag = "HitboxSize",
    Callback = function(p106)
        vu96 = p106
    end
})
v36:CreateSlider({
    Name = "Hitbox Transparency",
    Range = {
        0,
        1
    },
    Increment = 0.05,
    CurrentValue = vu97,
    Flag = "HitboxTransparency",
    Callback = function(p107)
        vu97 = p107
    end
})
v36:CreateColorPicker({
    Name = "Hitbox Color",
    Color = Color3.fromRGB(0, 0, 255),
    Flag = "HitboxColor",
    Callback = function(p108)
        vu98 = BrickColor.new(p108)
    end
})
game:GetService("RunService").RenderStepped:Connect(function()
    if vu95 then
        local v109, v110, v111 = ipairs(game:GetService("Players"):GetPlayers())
        while true do
            local v112
            v111, v112 = v109(v110, v111)
            if v111 == nil then
                break
            end
            if v112 ~= game.Players.LocalPlayer then
                local vu113 = v112.Character
                if vu113 and vu113:FindFirstChild("HumanoidRootPart") then
                    pcall(function()
                        local v114 = vu113.HumanoidRootPart
                        v114.Size = Vector3.new(vu96, vu96, vu96)
                        v114.Transparency = vu97
                        v114.BrickColor = vu98
                        v114.Material = Enum.Material.Neon
                        v114.CanCollide = false
                    end)
                end
            end
        end
    end
end)
v38:CreateToggle({
    Name = "View Model Editor",
    CurrentValue = false,
    Flag = "RecoilModifier",
    Callback = function(p115)
        vu26 = p115
        if p115 then
            vu1:Notify({
                Title = "View Model Editor",
                Content = "Reset to enable!",
                Duration = 1,
                Image = 4483362458
            })
        else
            vu1:Notify({
                Title = "View Model Editor",
                Content = "Reset to disable!",
                Duration = 1,
                Image = 4483362458
            })
        end
        while vu26 do
            if vu5.Character then
                local v116 = vu5.Character:FindFirstChildWhichIsA("Tool")
                if v116 and v116:FindFirstChild("Configuration") then
                    local v117, v118, v119 = ipairs(v116.Configuration:GetChildren())
                    while true do
                        local v120
                        v119, v120 = v117(v118, v119)
                        if v119 == nil then
                            break
                        end
                        if v120.Name == "ViewModelOffset" and vu26 then
                            v120.Value = vu27
                        end
                    end
                end
            end
            task.wait()
        end
    end
})
v38:CreateSlider({
    Name = "View Model X",
    Range = {
        - 10,
        10
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "ViewModelX",
    Callback = function(p121)
        vu27 = Vector3.new(p121, vu27.Y, vu27.Z)
        vu1:Notify({
            Title = "View Model X",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v38:CreateSlider({
    Name = "View Model Y",
    Range = {
        - 10,
        10
    },
    Increment = 1,
    CurrentValue = - 4,
    Flag = "ViewModelY",
    Callback = function(p122)
        vu27 = Vector3.new(vu27.X, p122, vu27.Z)
        vu1:Notify({
            Title = "View Model Y",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v38:CreateSlider({
    Name = "View Model Z",
    Range = {
        - 10,
        10
    },
    Increment = 1,
    CurrentValue = 0,
    Flag = "ViewModelZ",
    Callback = function(p123)
        vu27 = Vector3.new(vu27.X, vu27.Y, p123)
        vu1:Notify({
            Title = "View Model Z",
            Content = "Reset to update!",
            Duration = 1,
            Image = 4483362458
        })
    end
})
v39:CreateToggle({
    Name = "Enable Walkspeed Changer",
    CurrentValue = false,
    Flag = "WalkspeedEnabled",
    Callback = function(p124)
        vu13 = p124
        if not p124 and vu5.Character and vu5.Character:FindFirstChild("Humanoid") then
            local v125 = vu5.Character.Humanoid
            local v126, v127, v128 = pairs(getconnections(v125:GetPropertyChangedSignal("WalkSpeed")))
            while true do
                local v129
                v128, v129 = v126(v127, v128)
                if v128 == nil then
                    break
                end
                v129:Disable()
            end
            v125.WalkSpeed = 16
        end
    end
})
v39:CreateSlider({
    Name = "Walkspeed",
    Range = {
        16,
        100
    },
    Increment = 1,
    CurrentValue = vu14,
    Flag = "WalkspeedValue",
    Callback = function(p130)
        vu14 = p130
        if vu13 and vu5.Character and vu5.Character:FindFirstChild("Humanoid") then
            local v131 = vu5.Character.Humanoid
            local v132, v133, v134 = pairs(getconnections(v131:GetPropertyChangedSignal("WalkSpeed")))
            while true do
                local v135
                v134, v135 = v132(v133, v134)
                if v134 == nil then
                    break
                end
                v135:Disable()
            end
            v131.WalkSpeed = vu14
        end
    end
})
game:GetService("RunService").Stepped:Connect(function()
    if vu13 and vu5.Character and (vu5.Character:FindFirstChild("Humanoid") and vu5.Character.Humanoid.WalkSpeed ~= vu14) then
        local v136 = vu5.Character.Humanoid
        local v137, v138, v139 = pairs(getconnections(v136:GetPropertyChangedSignal("WalkSpeed")))
        while true do
            local v140
            v139, v140 = v137(v138, v139)
            if v139 == nil then
                break
            end
            v140:Disable()
        end
        v136.WalkSpeed = vu14
    end
end)
local vu141 = false
v39:CreateToggle({
    Name = "Infinite Jump",
    CurrentValue = false,
    Flag = "InfiniteJump",
    Callback = function(p142)
        vu141 = p142
        if vu141 then
            vu1:Notify({
                Title = "Infinite Jump",
                Content = "Enabled",
                Duration = 1,
                Image = 4483362458
            })
        else
            vu1:Notify({
                Title = "Infinite Jump",
                Content = "Disabled",
                Duration = 1,
                Image = 4483362458
            })
        end
    end
})
local vu143 = nil
game:GetService("UserInputService").JumpRequest:Connect(function()
    if vu141 and vu5.Character and vu5.Character:FindFirstChildOfClass("Humanoid") then
        local vu144 = vu5.Character.Humanoid
        if vu144:GetState() ~= Enum.HumanoidStateType.Jumping and vu144:GetState() ~= Enum.HumanoidStateType.Freefall then
            if not vu143 then
                vu143 = vu144.JumpPower
            end
            vu144.JumpPower = 50
            vu144:ChangeState(Enum.HumanoidStateType.Jumping)
            task.delay(0.1, function()
                if vu144 then
                    vu144.JumpPower = vu143 or 50
                end
            end)
        end
    end
end)
local v145 = vu1
vu1.LoadConfiguration(v145)